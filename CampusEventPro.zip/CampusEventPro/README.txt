BRAINWARE UNIVERSITY - CAMPUS EVENTS & CLUBS MANAGEMENT SYSTEM
==============================================================

A web-based platform for managing university campus events, clubs, and student engagement.

QUICK START
----------
1. Install Node.js (v18+) and PostgreSQL
2. Install dependencies: npm install
3. Configure database: Set DATABASE_URL in .env file
4. Initialize database: npm run db:push
5. Start development server: npm run dev
6. Access the application at: http://localhost:5000

DEFAULT ADMIN LOGIN
------------------
Username: akinchan_25
Password: 123456

MAIN FEATURES
------------
- Event browsing, filtering, and registration
- Club management and membership
- Payment processing for event registration fees
- Role-based access (Student/Admin)
- Admin dashboard for system management

TECHNOLOGY STACK
---------------
- Frontend: React, TypeScript, TailwindCSS, Shadcn UI
- Backend: Node.js, Express, PostgreSQL, Drizzle ORM
- Authentication: Passport.js with session-based auth
- UI: Custom design with Spline 3D backgrounds

SYSTEM REQUIREMENTS
------------------
- Node.js v18+
- PostgreSQL database
- Modern web browser (Chrome, Firefox, Safari, Edge)

PROJECT STRUCTURE
----------------
/client       - Frontend React application
/server       - Backend Express API
/shared       - Shared TypeScript types and schemas

AVAILABLE COMMANDS
-----------------
npm run dev   - Start development server
npm run db:push - Update database schema
npm run build - Build for production
npm run start - Start production server

USER ROLES
---------
1. Student
   - Browse and register for events
   - Join and create clubs
   - Manage personal registrations

2. Administrator
   - All student capabilities
   - Create/edit/delete events and clubs
   - Manage system data via admin dashboard

CONTACT & SUPPORT
----------------
For support, contact Brainware University:
Email: contact@brainwareuniversity.ac.in
Website: https://www.brainwareuniversity.ac.in

© 2025 Brainware University. All rights reserved.