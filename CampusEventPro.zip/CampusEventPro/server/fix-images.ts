import { db } from './db';
import { events } from '@shared/schema';

async function fixEventImages() {
  console.log('Starting to fix all event images...');

  // Get all events
  const allEvents = await db.select().from(events);
  console.log(`Found ${allEvents.length} events to fix.`);
  
  // New reliable image URLs
  const imageUrls = [
    'https://images.pexels.com/photos/7096/people-woman-coffee-meeting.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Hackathon
    'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Cultural Festival
    'https://images.pexels.com/photos/945471/pexels-photo-945471.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Basketball
    'https://images.pexels.com/photos/1787235/pexels-photo-1787235.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Photography Exhibition
    'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // AI Workshop
    'https://images.pexels.com/photos/6646918/pexels-photo-6646918.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Public Speaking
    'https://images.pexels.com/photos/4974915/pexels-photo-4974915.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Web Development
    'https://images.pexels.com/photos/5060569/pexels-photo-5060569.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Dance Competition
    'https://images.pexels.com/photos/3184296/pexels-photo-3184296.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Soccer Tournament
    'https://images.pexels.com/photos/3617496/pexels-photo-3617496.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Photography Walk
    'https://images.pexels.com/photos/7096/people-woman-coffee-meeting.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // ML Study Group
    'https://images.pexels.com/photos/6325984/pexels-photo-6325984.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // MUN Conference
    'https://images.pexels.com/photos/3861964/pexels-photo-3861964.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // App Development 
    'https://images.pexels.com/photos/3662830/pexels-photo-3662830.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Traditional Music
    'https://images.pexels.com/photos/3759660/pexels-photo-3759660.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Yoga Retreat
    'https://images.pexels.com/photos/5899765/pexels-photo-5899765.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Wildlife Photography
    'https://images.pexels.com/photos/7988086/pexels-photo-7988086.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Data Science Hackathon
    'https://images.pexels.com/photos/6457517/pexels-photo-6457517.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Ethics Debate
    'https://images.pexels.com/photos/1921326/pexels-photo-1921326.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Game Development
    'https://images.pexels.com/photos/1640770/pexels-photo-1640770.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Food Festival
    'https://images.pexels.com/photos/8294606/pexels-photo-8294606.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Robotics
    'https://images.pexels.com/photos/238480/pexels-photo-238480.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Poetry
    'https://images.pexels.com/photos/863988/pexels-photo-863988.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Swimming
    'https://images.pexels.com/photos/3341231/pexels-photo-3341231.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Portrait Photography
    'https://images.pexels.com/photos/8370752/pexels-photo-8370752.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Blockchain Seminar
    'https://images.pexels.com/photos/5668859/pexels-photo-5668859.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Mock Trial
    'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Cybersecurity
    'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Film Festival
    'https://images.pexels.com/photos/8224058/pexels-photo-8224058.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Frisbee Tournament
    'https://images.pexels.com/photos/631477/pexels-photo-631477.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Astrophotography
  ];
  
  try {
    for (let i = 0; i < allEvents.length; i++) {
      const event = allEvents[i];
      const imageUrl = imageUrls[i % imageUrls.length]; // Use modulo to cycle through images if we have more events than images
      
      console.log(`Updating event ${event.id}: ${event.title} with new image URL`);
      
      await db.update(events)
        .set({ image: imageUrl })
        .where(events.id === event.id);
    }
    
    console.log('All event images fixed successfully!');
  } catch (error) {
    console.error('Error fixing event images:', error);
  }
}

// Run the function
fixEventImages().catch(console.error);