import { db } from './db';
import { events, Event } from '@shared/schema';

async function seedEvents() {
  console.log('Starting event seeding...');

  // Check if events already exist
  const existingEvents = await db.select().from(events);
  if (existingEvents.length > 0) {
    console.log(`Found ${existingEvents.length} existing events. Skipping seeding.`);
    return;
  }

  const sampleEvents = [
    {
      title: "Hackathon 2023",
      description: "A 48-hour coding competition to build innovative solutions for real-world problems.",
      date: new Date("2023-12-10"),
      time: "09:00 AM",
      location: "Main Campus, Tech Building",
      price: 0,
      capacity: 100,
      image: "https://images.unsplash.com/photo-1504384764586-bb4cdc1707b0?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y29kaW5nJTIwY29tcGV0aXRpb258ZW58MHx8MHx8fDA%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 1, // Coding Club
      categoryId: 1, // Technology
      highlights: ["Amazing prizes", "Industry mentors", "Free food and swag"]
    },
    {
      title: "Cultural Festival",
      description: "Celebrate diversity through performances, food, and activities from different cultures.",
      date: new Date("2023-11-15"),
      time: "10:00 AM",
      location: "Campus Quad",
      price: 5,
      capacity: 500,
      image: "https://images.unsplash.com/photo-1569930784237-ea65a2129a63?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8Y3VsdHVyYWwlMjBmZXN0aXZhbHxlbnwwfHwwfHx8MA%3D%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 2, // Cultural Club
      categoryId: 2, // Cultural
      highlights: ["Live performances", "International cuisine", "Cultural workshops"]
    },
    {
      title: "Basketball Tournament",
      description: "Compete in our annual basketball tournament. Both men's and women's leagues available.",
      date: new Date("2023-11-20"),
      time: "02:00 PM",
      location: "Sports Complex",
      price: 10,
      capacity: 120,
      image: "https://images.unsplash.com/photo-1512412046876-f386342eddb3?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fGJhc2tldGJhbGwlMjB0b3VybmFtZW50fGVufDB8fDB8fHww",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 3, // Sports Club
      categoryId: 3, // Sports
      highlights: ["Trophies for winners", "Team and individual prizes", "Professional referees"]
    },
    {
      title: "Photography Exhibition",
      description: "Showcase of student photography projects and a chance to learn from professionals.",
      date: new Date("2023-11-25"),
      time: "11:00 AM",
      location: "Art Gallery",
      price: 0,
      capacity: 200,
      image: "https://images.unsplash.com/photo-1570858073902-16f496d8d42d?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8cGhvdG9ncmFwaHklMjBleGhpYml0aW9ufGVufDB8fDB8fHww",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 4, // Photography Club
      categoryId: 6, // Arts
      highlights: ["Guest photographers", "Equipment showcase", "Photography contest"]
    },
    {
      title: "AI Workshop",
      description: "Learn the basics of artificial intelligence and machine learning in this hands-on workshop.",
      date: new Date("2023-12-05"),
      time: "01:00 PM",
      location: "Computer Lab 101",
      price: 15,
      capacity: 50,
      image: "https://images.unsplash.com/photo-1591453089816-0fbb971b454c?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8YXJ0aWZpY2lhbCUyMGludGVsbGlnZW5jZXxlbnwwfHwwfHx8MA%3D%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 5, // AI Society
      categoryId: 5, // Workshop
      highlights: ["Practical exercises", "Certificate of completion", "No prior experience needed"]
    },
    {
      title: "Public Speaking Competition",
      description: "Test your oratory skills in various formats including prepared speeches and impromptu debates.",
      date: new Date("2023-12-12"),
      time: "03:00 PM",
      location: "Auditorium",
      price: 5,
      capacity: 80,
      image: "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8cHVibGljJTIwc3BlYWtpbmd8ZW58MHx8MHx8fDA%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 6, // Debate Club
      categoryId: 4, // Academic
      highlights: ["Expert judges", "Valuable feedback", "Great networking opportunity"]
    }
  ];

  console.log(`Inserting ${sampleEvents.length} sample events...`);

  try {
    for (const event of sampleEvents) {
      await db.insert(events).values(event);
    }
    console.log('Events seeded successfully!');
  } catch (error) {
    console.error('Error seeding events:', error);
  }
}

// Run the seeding function
seedEvents().catch(console.error);