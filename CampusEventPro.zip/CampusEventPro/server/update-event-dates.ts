import { db } from './db';
import { events } from '@shared/schema';
import { eq } from 'drizzle-orm';

async function updateEventDates() {
  console.log('Starting to update event dates based on May 1, 2025...');
  
  const currentDate = new Date('2025-05-01');
  console.log(`Current date: ${currentDate.toLocaleDateString()}`);
  
  // Past events (closed)
  const pastEvents = [1, 3, 5, 7, 9, 11, 13, 15];
  
  // Upcoming events (still open)
  const upcomingEvents = [2, 4, 6, 8, 10, 12, 14, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30];
  
  try {
    // Set past events (dates from Jan-April 2025)
    for (const eventId of pastEvents) {
      // Generate a random date from January to April 2025
      const month = Math.floor(Math.random() * 4) + 1; // 1-4 (Jan-Apr)
      const day = Math.floor(Math.random() * 28) + 1; // 1-28
      const pastDate = new Date(`2025-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`);
      
      await db.update(events)
        .set({ 
          date: pastDate,
          status: 'closed'
        })
        .where(eq(events.id, eventId));
      
      console.log(`Updated event ${eventId} with past date: ${pastDate.toLocaleDateString()} (closed)`);
    }
    
    // Set upcoming events (dates from May-December 2025)
    for (const eventId of upcomingEvents) {
      // Generate a random date from May to December 2025
      const month = Math.floor(Math.random() * 8) + 5; // 5-12 (May-Dec)
      const day = Math.floor(Math.random() * 28) + 1; // 1-28
      const futureDate = new Date(`2025-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`);
      
      await db.update(events)
        .set({ 
          date: futureDate,
          status: 'upcoming'
        })
        .where(eq(events.id, eventId));
      
      console.log(`Updated event ${eventId} with future date: ${futureDate.toLocaleDateString()} (upcoming)`);
    }
    
    console.log('All event dates and statuses updated successfully!');
  } catch (error) {
    console.error('Error updating event dates:', error);
  }
}

// Run the function
updateEventDates().catch(console.error);