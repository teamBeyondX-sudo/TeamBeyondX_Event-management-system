import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { insertEventSchema, insertRegistrationSchema, insertClubSchema, User } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Admin middleware - verifies if user is admin
  const isAdmin = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    if (req.user.role !== "admin") {
      return res.status(403).json({ message: "Not authorized" });
    }
    
    next();
  };

  // Get all categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Get all clubs
  app.get("/api/clubs", async (req, res) => {
    try {
      const clubs = await storage.getClubs();
      res.json(clubs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch clubs" });
    }
  });
  
  // Create a new club (available to all authenticated users)
  app.post("/api/clubs", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const clubData = insertClubSchema.parse(req.body);
      const club = await storage.createClub(clubData);
      
      // Automatically make creator a member (and leader) of the club
      const userId = (req.user as any).id;
      await storage.createClubMembership({
        userId,
        clubId: club.id,
        role: "leader"
      });
      
      res.status(201).json(club);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid club data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create club" });
    }
  });
  
  // Delete a club (admin only)
  app.delete("/api/clubs/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const club = await storage.getClub(id);
      
      if (!club) {
        return res.status(404).json({ message: "Club not found" });
      }
      
      // Check if club has events with registrations
      const events = await storage.getEventsByClub(id);
      for (const event of events) {
        const registrations = await storage.getRegistrationsByEvent(event.id);
        if (registrations.length > 0) {
          return res.status(400).json({ 
            message: "Cannot delete club with active registrations. Cancel all event registrations first." 
          });
        }
      }
      
      await storage.deleteClub(id);
      res.status(200).json({ message: "Club deleted successfully" });
    } catch (error) {
      console.error("Error deleting club:", error);
      res.status(500).json({ message: "Failed to delete club" });
    }
  });

  // Get single club
  app.get("/api/clubs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const club = await storage.getClub(id);
      
      if (!club) {
        return res.status(404).json({ message: "Club not found" });
      }
      
      // Get events for this club
      const events = await storage.getEventsByClub(id);
      
      res.json({
        ...club,
        events
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch club" });
    }
  });
  
  // Get members of a club
  app.get("/api/clubs/:id/members", async (req, res) => {
    try {
      const clubId = parseInt(req.params.id, 10);
      const club = await storage.getClub(clubId);
      
      if (!club) {
        return res.status(404).json({ message: "Club not found" });
      }
      
      const members = await storage.getClubMembersDetails(clubId);
      
      res.json({
        clubName: club.name,
        clubIcon: club.icon,
        clubBackgroundColor: club.backgroundColor,
        totalMembers: members.length,
        members
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch club members" });
    }
  });
  
  // Join a club
  app.post("/api/clubs/:id/join", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const clubId = parseInt(req.params.id, 10);
      const userId = (req.user as any).id;
      
      console.log("Join club request:", { clubId, userId, body: req.body });
      
      const club = await storage.getClub(clubId);
      if (!club) {
        return res.status(404).json({ message: "Club not found" });
      }
      
      // Check if user is already a member
      const existingMemberships = await storage.getClubMembershipsByUser(userId);
      const alreadyMember = existingMemberships.some(m => m.clubId === clubId);
      
      if (alreadyMember) {
        return res.status(400).json({ message: "Already a member of this club" });
      }
      
      // Create membership
      const membership = await storage.createClubMembership({
        userId,
        clubId,
        role: req.body.role || "member"
      });
      
      res.status(201).json(membership);
    } catch (error) {
      console.error("Failed to join club:", error);
      res.status(500).json({ message: "Failed to join club" });
    }
  });
  
  // Leave a club
  app.delete("/api/clubs/:id/leave", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const clubId = parseInt(req.params.id, 10);
      const userId = (req.user as any).id;
      
      const club = await storage.getClub(clubId);
      if (!club) {
        return res.status(404).json({ message: "Club not found" });
      }
      
      // Check if user is a member
      const existingMemberships = await storage.getClubMembershipsByUser(userId);
      const isMember = existingMemberships.some(m => m.clubId === clubId);
      
      if (!isMember) {
        return res.status(400).json({ message: "Not a member of this club" });
      }
      
      // Remove membership
      await storage.deleteClubMembership(userId, clubId);
      
      res.status(200).json({ message: "Successfully left the club" });
    } catch (error) {
      res.status(500).json({ message: "Failed to leave club" });
    }
  });
  
  // Get clubs the current user is a member of
  app.get("/api/my-clubs", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userId = (req.user as any).id;
      const memberships = await storage.getClubMembershipsByUser(userId);
      
      // Get club details for each membership
      const clubs = await Promise.all(
        memberships.map(async (membership) => {
          const club = await storage.getClub(membership.clubId);
          return club ? {
            ...club,
            role: membership.role,
            joinDate: membership.joinDate
          } : null;
        })
      );
      
      // Filter out any null values
      const validClubs = clubs.filter(Boolean);
      
      res.json(validClubs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch your clubs" });
    }
  });

  // Get all events
  app.get("/api/events", async (req, res) => {
    try {
      const { categoryId, clubId, search } = req.query;
      let filters: any = {};
      
      if (categoryId) {
        filters.categoryId = parseInt(categoryId as string, 10);
      }
      
      if (clubId) {
        filters.clubId = parseInt(clubId as string, 10);
      }
      
      let events = await storage.getEvents(filters);
      
      // Handle search
      if (search && typeof search === 'string') {
        const searchTerm = search.toLowerCase();
        events = events.filter(event => 
          event.title.toLowerCase().includes(searchTerm) || 
          event.description.toLowerCase().includes(searchTerm)
        );
      }
      
      // Fetch club details for each event and add registration status based on event date
      const currentDate = new Date('2025-05-01');
      const eventsWithClub = await Promise.all(
        events.map(async (event) => {
          const club = await storage.getClub(event.clubId);
          const category = await storage.getCategory(event.categoryId);
          
          // Check if registration is possible based on status
          const isRegistrationOpen = event.status === "upcoming";
          const eventDate = new Date(event.date);
          const isPastEvent = eventDate < currentDate;
          const statusText = isPastEvent ? "Closed" : "Upcoming";
          
          return {
            ...event,
            club,
            category,
            isRegistrationOpen,
            statusText
          };
        })
      );
      
      res.json(eventsWithClub);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  // Get single event
  app.get("/api/events/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const event = await storage.getEvent(id);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      const club = await storage.getClub(event.clubId);
      const category = await storage.getCategory(event.categoryId);
      
      // Add status information
      const currentDate = new Date('2025-05-01');
      const eventDate = new Date(event.date);
      const isPastEvent = eventDate < currentDate;
      const statusText = isPastEvent ? "Closed" : "Upcoming";
      const isRegistrationOpen = event.status === "upcoming";
      
      res.json({
        ...event,
        club,
        category,
        isRegistrationOpen,
        statusText
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch event" });
    }
  });

  // Create event (for admins only, but events will be visible to all users)
  app.post("/api/events", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userId = (req.user as any).id;
      const clubId = req.body.clubId;
      
      // ONLY admins can create events
      const isUserAdmin = (req.user as any).role === "admin";
      
      if (!isUserAdmin) {
        return res.status(403).json({ 
          message: "Only administrators can create events. Please contact an admin for assistance." 
        });
      }
      
      // First validate the event data with the schema that accepts string dates
      const eventData = insertEventSchema.parse(req.body);
      
      // Ensure club exists
      const club = await storage.getClub(clubId);
      if (!club) {
        return res.status(400).json({ 
          message: "Invalid club selected. Please select a valid club." 
        });
      }
      
      // Ensure the date and numeric fields are properly formatted
      const formattedData = {
        ...eventData,
        // If date is a string, convert it to a Date object for proper storage
        date: typeof eventData.date === 'string' ? new Date(eventData.date) : eventData.date,
        clubId: parseInt(String(eventData.clubId), 10),
        categoryId: parseInt(String(eventData.categoryId), 10),
        price: parseInt(String(eventData.price), 10) || 0,
        capacity: parseInt(String(eventData.capacity), 10) || 50,
        highlights: Array.isArray(eventData.highlights) ? eventData.highlights : [],
      };
      
      // Create the event in the database
      console.log("Creating event with data:", formattedData);
      const event = await storage.createEvent(formattedData);
      
      res.status(201).json(event);
    } catch (error) {
      console.error("Error creating event:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid event data", 
          errors: error.errors,
          details: "Please check all required fields, especially dates and numeric values." 
        });
      }
      res.status(500).json({ 
        message: "Failed to create event", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Update event (admin only)
  app.patch("/api/events/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const event = await storage.getEvent(id);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      const updatedEvent = await storage.updateEvent(id, req.body);
      res.json(updatedEvent);
    } catch (error) {
      res.status(500).json({ message: "Failed to update event" });
    }
  });
  
  // Delete event (admin only)
  app.delete("/api/events/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const event = await storage.getEvent(id);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // First check if there are registrations for this event
      const registrations = await storage.getRegistrationsByEvent(id);
      
      if (registrations.length > 0) {
        return res.status(400).json({ 
          message: "Cannot delete event with existing registrations. Cancel registrations first." 
        });
      }
      
      await storage.deleteEvent(id);
      res.status(200).json({ message: "Event deleted successfully" });
    } catch (error) {
      console.error("Error deleting event:", error);
      res.status(500).json({ message: "Failed to delete event" });
    }
  });

  // Get user registrations
  app.get("/api/registrations", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userId = (req.user as any).id;
      const registrations = await storage.getRegistrationsByUser(userId);
      
      // Fetch event details for each registration
      const registrationsWithDetails = await Promise.all(
        registrations.map(async (registration) => {
          const event = await storage.getEvent(registration.eventId);
          const club = event ? await storage.getClub(event.clubId) : null;
          const category = event ? await storage.getCategory(event.categoryId) : null;
          
          return {
            ...registration,
            event: event ? {
              ...event,
              club,
              category
            } : null
          };
        })
      );
      
      res.json(registrationsWithDetails);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch registrations" });
    }
  });

  // Register for an event
  app.post("/api/events/:id/register", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const eventId = parseInt(req.params.id, 10);
      const userId = (req.user as any).id;
      
      // Check if event exists and has available capacity
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      if (event.registrationsCount >= event.capacity) {
        return res.status(400).json({ message: "Event is at full capacity" });
      }
      
      // Check if event is open for registration (must be upcoming)
      if (event.status !== "upcoming") {
        return res.status(400).json({ message: "Registration is closed for this event" });
      }
      
      // Check if user is already registered
      const existingRegistration = await storage.getRegistrationByUserAndEvent(userId, eventId);
      if (existingRegistration) {
        return res.status(400).json({ message: "Already registered for this event" });
      }
      
      // Create registration
      const registrationData = {
        ...req.body,
        userId,
        eventId,
        paymentAmount: event.price
      };
      
      const validatedData = insertRegistrationSchema.parse(registrationData);
      const registration = await storage.createRegistration(validatedData);
      
      res.status(201).json(registration);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid registration data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to register for event" });
    }
  });

  // Process payment for registration
  app.post("/api/registrations/:id/payment", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const id = parseInt(req.params.id, 10);
      const registration = await storage.getRegistration(id);
      
      if (!registration) {
        return res.status(404).json({ message: "Registration not found" });
      }
      
      if (registration.userId !== (req.user as any).id) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      // Mock payment processing
      const transactionId = `TXN${Math.floor(Math.random() * 1000000)}`;
      
      const updatedRegistration = await storage.updateRegistration(id, {
        paymentStatus: "completed",
        transactionId
      });
      
      res.json(updatedRegistration);
    } catch (error) {
      res.status(500).json({ message: "Failed to process payment" });
    }
  });

  // Admin Routes
  
  // Get all registrations for an event (admin only)
  app.get("/api/events/:id/registrations", isAdmin, async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      const registrations = await storage.getRegistrationsByEvent(eventId);
      
      // Fetch user details for each registration
      const registrationsWithUsers = await Promise.all(
        registrations.map(async (registration) => {
          const user = await storage.getUser(registration.userId);
          return {
            ...registration,
            user: user ? {
              id: user.id,
              username: user.username,
              fullName: user.fullName,
              email: user.email,
              phone: user.phone
            } : null
          };
        })
      );
      
      res.json(registrationsWithUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch registrations" });
    }
  });

  // Get admin dashboard stats
  app.get("/api/admin/stats", isAdmin, async (req, res) => {
    try {
      const events = await storage.getEvents();
      const totalEvents = events.length;
      
      // Calculate total registrations and revenue
      let totalRegistrations = 0;
      let totalRevenue = 0;
      
      events.forEach(event => {
        totalRegistrations += event.registrationsCount;
        totalRevenue += event.registrationsCount * event.price;
      });
      
      const clubs = await storage.getClubs();
      const activeClubs = clubs.length;
      
      res.json({
        totalEvents,
        totalRegistrations,
        totalRevenue,
        activeClubs
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
