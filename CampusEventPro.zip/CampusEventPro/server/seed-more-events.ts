import { db } from './db';
import { events, Event } from '@shared/schema';

async function seedMoreEvents() {
  console.log('Starting additional event seeding...');

  // Get current max event ID to ensure we don't have ID conflicts
  const existingEvents = await db.select().from(events);
  const maxId = Math.max(...existingEvents.map(e => e.id), 0);
  console.log(`Found ${existingEvents.length} existing events. Starting from ID ${maxId + 1}`);

  const additionalEvents = [
    {
      title: "Web Development Bootcamp",
      description: "Intensive 2-day workshop covering HTML, CSS, JavaScript, and modern frameworks.",
      date: new Date("2023-12-15"),
      time: "09:00 AM",
      location: "Computer Science Building, Room 301",
      price: 25,
      capacity: 40,
      image: "https://images.unsplash.com/photo-1610986603166-f78428624e76?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fHdlYiUyMGRldmVsb3BtZW50fGVufDB8fDB8fHww",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 1, // Coding Club
      categoryId: 5, // Workshop
      highlights: ["Build a portfolio project", "Learn from industry experts", "Certificate on completion"]
    },
    {
      title: "Dance Competition",
      description: "Annual dance-off featuring solo, duo, and group performances in various dance styles.",
      date: new Date("2023-12-18"),
      time: "05:00 PM",
      location: "Main Auditorium",
      price: 8,
      capacity: 300,
      image: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8ZGFuY2UlMjBjb21wZXRpdGlvbnxlbnwwfHwwfHx8MA%3D%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 2, // Cultural Club
      categoryId: 2, // Cultural
      highlights: ["Cash prizes", "Professional judges", "Performance certificate"]
    },
    {
      title: "Soccer Tournament",
      description: "Inter-college soccer tournament with divisions for different skill levels.",
      date: new Date("2023-12-20"),
      time: "10:00 AM",
      location: "College Soccer Field",
      price: 12,
      capacity: 150,
      image: "https://images.unsplash.com/photo-1552667466-07770ae110d0?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8c29jY2VyJTIwdG91cm5hbWVudHxlbnwwfHwwfHx8MA%3D%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 3, // Sports Club
      categoryId: 3, // Sports
      highlights: ["Team trophies", "Individual awards", "Refreshments provided"]
    },
    {
      title: "Street Photography Walk",
      description: "Guided photography walk through the city, focusing on urban landscapes and street photography techniques.",
      date: new Date("2023-12-08"),
      time: "03:00 PM",
      location: "Meet at Campus Main Gate",
      price: 5,
      capacity: 30,
      image: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHN0cmVldCUyMHBob3RvZ3JhcGh5fGVufDB8fDB8fHww",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 4, // Photography Club
      categoryId: 6, // Arts
      highlights: ["Professional guidance", "Feedback on photos", "Best photo award"]
    },
    {
      title: "Machine Learning Study Group",
      description: "Weekly study group focusing on machine learning algorithms and practical implementations.",
      date: new Date("2023-12-07"),
      time: "06:00 PM",
      location: "Library Study Room B",
      price: 0,
      capacity: 25,
      image: "https://images.unsplash.com/photo-1456428746267-a1756408f782?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c3R1ZHklMjBncm91cHxlbnwwfHwwfHx8MA%3D%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 5, // AI Society
      categoryId: 4, // Academic
      highlights: ["Collaborative learning", "Practical exercises", "Research paper discussions"]
    },
    {
      title: "Model United Nations Conference",
      description: "Simulate United Nations committees and debate global issues in this two-day conference.",
      date: new Date("2023-12-16"),
      time: "09:00 AM",
      location: "Conference Center",
      price: 20,
      capacity: 100,
      image: "https://images.unsplash.com/photo-1530023367847-a683933f4172?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8bW9kZWwlMjB1bml0ZWQlMjBuYXRpb25zfGVufDB8fDB8fHww",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 6, // Debate Club
      categoryId: 4, // Academic
      highlights: ["Develop diplomatic skills", "Awards for best delegates", "Networking opportunities"]
    },
    {
      title: "Mobile App Development Challenge",
      description: "One-week challenge to develop a mobile app that addresses a campus issue or need.",
      date: new Date("2024-01-05"),
      time: "All day",
      location: "Virtual",
      price: 0,
      capacity: 60,
      image: "https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8YXBwJTIwZGV2ZWxvcG1lbnR8ZW58MHx8MHx8fDA%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 1, // Coding Club
      categoryId: 1, // Technology
      highlights: ["Implementation support", "Launch your app on campus", "Funding for top ideas"]
    },
    {
      title: "Traditional Music Workshop",
      description: "Learn to play traditional instruments from various cultures around the world.",
      date: new Date("2024-01-10"),
      time: "02:00 PM",
      location: "Music Room, Arts Building",
      price: 10,
      capacity: 35,
      image: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8bXVzaWMlMjB3b3Jrc2hvcHxlbnwwfHwwfHx8MA%3D%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 2, // Cultural Club
      categoryId: 5, // Workshop
      highlights: ["Hands-on experience", "Instruments provided", "Group performance opportunity"]
    },
    {
      title: "Yoga and Meditation Retreat",
      description: "Day-long retreat focusing on yoga, meditation, and mindfulness practices.",
      date: new Date("2023-12-22"),
      time: "08:00 AM",
      location: "Wellness Center",
      price: 15,
      capacity: 40,
      image: "https://images.unsplash.com/photo-1599447421416-3414eeac410a?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHlvZ2ElMjByZXRyZWF0fGVufDB8fDB8fHww",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 3, // Sports Club
      categoryId: 5, // Workshop
      highlights: ["All skill levels welcome", "Healthy refreshments", "Take-home practices"]
    },
    {
      title: "Wildlife Photography Trip",
      description: "Weekend trip to a nearby nature reserve to practice wildlife photography skills.",
      date: new Date("2024-01-20"),
      time: "06:00 AM",
      location: "Meet at Campus Parking Lot A",
      price: 30,
      capacity: 20,
      image: "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d2lsZGxpZmUlMjBwaG90b2dyYXBoeXxlbnwwfHwwfHx8MA%3D%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 4, // Photography Club
      categoryId: 6, // Arts
      highlights: ["Transportation included", "Expert wildlife guidance", "Photo critique session"]
    },
    {
      title: "Data Science Hackathon",
      description: "Use real-world datasets to develop innovative solutions to social problems.",
      date: new Date("2024-01-15"),
      time: "09:00 AM",
      location: "Innovation Lab",
      price: 10,
      capacity: 50,
      image: "https://images.unsplash.com/photo-1543286386-713bdd548da4?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8ZGF0YSUyMHNjaWVuY2V8ZW58MHx8MHx8fDA%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 5, // AI Society
      categoryId: 1, // Technology
      highlights: ["Access to premium datasets", "Mentorship from industry experts", "Cash prizes"]
    },
    {
      title: "Ethics Debate Competition",
      description: "Debate challenging ethical scenarios and dilemmas in this thought-provoking competition.",
      date: new Date("2024-01-25"),
      time: "01:00 PM",
      location: "Philosophy Department",
      price: 5,
      capacity: 60,
      image: "https://images.unsplash.com/photo-1573497620053-ea5300f94f21?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fGRlYmF0ZXxlbnwwfHwwfHx8MA%3D%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 6, // Debate Club
      categoryId: 4, // Academic
      highlights: ["Challenging scenarios", "Expert judges", "Certificates for all participants"]
    },
    {
      title: "Game Development Workshop",
      description: "Learn the basics of game development using Unity game engine in this hands-on workshop.",
      date: new Date("2024-02-05"),
      time: "10:00 AM",
      location: "Computer Lab 202",
      price: 15,
      capacity: 30,
      image: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTZ8fGdhbWUlMjBkZXZlbG9wbWVudHxlbnwwfHwwfHx8MA%3D%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 1, // Coding Club
      categoryId: 5, // Workshop
      highlights: ["Create your first game", "No prior experience needed", "Take-home assets and resources"]
    },
    {
      title: "International Food Festival",
      description: "Celebrate culinary diversity with food stalls representing cuisines from around the world.",
      date: new Date("2024-02-10"),
      time: "11:00 AM",
      location: "Campus Quad",
      price: 10,
      capacity: 500,
      image: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8Zm9vZCUyMGZlc3RpdmFsfGVufDB8fDB8fHww",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 2, // Cultural Club
      categoryId: 2, // Cultural
      highlights: ["20+ international cuisines", "Cooking demonstrations", "Recipe booklet included"]
    }
  ];

  console.log(`Inserting ${additionalEvents.length} additional events...`);

  try {
    for (const event of additionalEvents) {
      await db.insert(events).values(event);
    }
    console.log('Additional events seeded successfully!');
  } catch (error) {
    console.error('Error seeding additional events:', error);
  }
}

// Run the seeding function
seedMoreEvents().catch(console.error);