import { db } from './db';
import { events } from '@shared/schema';
import { eq } from 'drizzle-orm';

async function updateEventImages() {
  console.log('Starting to update all event images with thematically related content...');
  
  // Define specific images for each event by ID
  const eventImagesMap: Record<number, string> = {
    // Technology events
    1: 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Hackathon 2023
    5: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // AI Workshop
    7: 'https://images.pexels.com/photos/4974915/pexels-photo-4974915.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Web Development
    11: 'https://images.pexels.com/photos/1181271/pexels-photo-1181271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // ML Study Group
    13: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // App Development
    17: 'https://images.pexels.com/photos/669615/pexels-photo-669615.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Data Science Hackathon
    19: 'https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Game Development
    21: 'https://images.pexels.com/photos/8294606/pexels-photo-8294606.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Robotics Competition
    25: 'https://images.pexels.com/photos/315788/pexels-photo-315788.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Blockchain Seminar
    27: 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Cybersecurity Challenge
    
    // Cultural events
    2: 'https://images.pexels.com/photos/3738087/pexels-photo-3738087.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Cultural Festival
    6: 'https://images.pexels.com/photos/6646918/pexels-photo-6646918.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Public Speaking
    8: 'https://images.pexels.com/photos/2188012/pexels-photo-2188012.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Dance Competition
    12: 'https://images.pexels.com/photos/8108063/pexels-photo-8108063.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // MUN Conference
    14: 'https://images.pexels.com/photos/111287/pexels-photo-111287.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Traditional Music
    18: 'https://images.pexels.com/photos/6457517/pexels-photo-6457517.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Ethics Debate
    20: 'https://images.pexels.com/photos/5638331/pexels-photo-5638331.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Food Festival
    22: 'https://images.pexels.com/photos/3009356/pexels-photo-3009356.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Poetry Slam
    26: 'https://images.pexels.com/photos/5668859/pexels-photo-5668859.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Mock Trial
    28: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Film Festival
    
    // Sports events
    3: 'https://images.pexels.com/photos/358042/pexels-photo-358042.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Basketball Tournament
    9: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Soccer Tournament
    15: 'https://images.pexels.com/photos/4056535/pexels-photo-4056535.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Yoga Retreat
    23: 'https://images.pexels.com/photos/260598/pexels-photo-260598.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Swimming Competition
    29: 'https://images.pexels.com/photos/8224058/pexels-photo-8224058.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Frisbee Tournament
    
    // Photography events
    4: 'https://images.pexels.com/photos/1787235/pexels-photo-1787235.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Photography Exhibition
    10: 'https://images.pexels.com/photos/3617496/pexels-photo-3617496.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Street Photography
    16: 'https://images.pexels.com/photos/247431/pexels-photo-247431.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Wildlife Photography
    24: 'https://images.pexels.com/photos/3062541/pexels-photo-3062541.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Portrait Photography
    30: 'https://images.pexels.com/photos/312839/pexels-photo-312839.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Astrophotography
  };
  
  try {
    // Get all events to log progress
    const allEvents = await db.select().from(events);
    console.log(`Found ${allEvents.length} events to update with related images.`);
    
    // Update each event with its related image
    for (const [eventId, imageUrl] of Object.entries(eventImagesMap)) {
      const id = parseInt(eventId);
      const event = allEvents.find(e => e.id === id);
      
      if (event) {
        console.log(`Updating event ${id}: ${event.title} with thematically related image`);
        
        await db.update(events)
          .set({ image: imageUrl })
          .where(eq(events.id, id));
      }
    }
    
    console.log('All event images updated with thematically related content!');
  } catch (error) {
    console.error('Error updating event images:', error);
  }
}

// Run the function
updateEventImages().catch(console.error);