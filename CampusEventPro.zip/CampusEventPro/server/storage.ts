import { users, type User, type InsertUser } from "@shared/schema";
import { clubs, type Club, type InsertClub } from "@shared/schema";
import { categories, type Category, type InsertCategory } from "@shared/schema";
import { events, type Event, type InsertEvent } from "@shared/schema";
import { registrations, type Registration, type InsertRegistration } from "@shared/schema";
import { clubMemberships, type ClubMembership, type InsertClubMembership } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { db, pool } from "./db";
import { eq, and } from "drizzle-orm";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Club operations
  getClub(id: number): Promise<Club | undefined>;
  getClubs(): Promise<Club[]>;
  createClub(club: InsertClub): Promise<Club>;
  updateClub(id: number, club: Partial<Club>): Promise<Club | undefined>;
  deleteClub(id: number): Promise<void>;
  
  // Club membership operations
  getClubMembership(id: number): Promise<ClubMembership | undefined>;
  getClubMemberships(clubId: number): Promise<ClubMembership[]>;
  getClubMembershipsByUser(userId: number): Promise<ClubMembership[]>;
  createClubMembership(membership: InsertClubMembership): Promise<ClubMembership>;
  deleteClubMembership(userId: number, clubId: number): Promise<void>;
  getClubMembersDetails(clubId: number): Promise<{user: {id: number, username: string, fullName: string, email: string}, role: string, joinDate: Date}[]>;
  
  // Category operations
  getCategory(id: number): Promise<Category | undefined>;
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Event operations
  getEvent(id: number): Promise<Event | undefined>;
  getEvents(filters?: Partial<Event>): Promise<Event[]>;
  getEventsByClub(clubId: number): Promise<Event[]>;
  getEventsByCategory(categoryId: number): Promise<Event[]>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: number, event: Partial<Event>): Promise<Event | undefined>;
  deleteEvent(id: number): Promise<void>;
  
  // Registration operations
  getRegistration(id: number): Promise<Registration | undefined>;
  getRegistrationByUserAndEvent(userId: number, eventId: number): Promise<Registration | undefined>;
  getRegistrationsByUser(userId: number): Promise<Registration[]>;
  getRegistrationsByEvent(eventId: number): Promise<Registration[]>;
  createRegistration(registration: InsertRegistration): Promise<Registration>;
  updateRegistration(id: number, registration: Partial<Registration>): Promise<Registration | undefined>;
  
  // Session store
  sessionStore: any; // Using any for session store type
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private clubs: Map<number, Club>;
  private categories: Map<number, Category>;
  private events: Map<number, Event>;
  private registrations: Map<number, Registration>;
  private clubMemberships: Map<number, ClubMembership>;
  
  private userIdCounter: number;
  private clubIdCounter: number;
  private categoryIdCounter: number;
  private eventIdCounter: number;
  private registrationIdCounter: number;
  private clubMembershipIdCounter: number;
  
  public sessionStore: any;

  constructor() {
    this.users = new Map();
    this.clubs = new Map();
    this.categories = new Map();
    this.events = new Map();
    this.registrations = new Map();
    this.clubMemberships = new Map();
    
    this.userIdCounter = 1;
    this.clubIdCounter = 1;
    this.categoryIdCounter = 1;
    this.eventIdCounter = 1;
    this.registrationIdCounter = 1;
    this.clubMembershipIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    // Initialize with sample data
    this.initializeSampleData();
  }
  
  private initializeSampleData() {
    // Initialize categories
    const categories: InsertCategory[] = [
      { name: "Technology", color: "#2563EB" },
      { name: "Cultural", color: "#9333EA" },
      { name: "Sports", color: "#2563EB" },
      { name: "Academic", color: "#DC2626" },
      { name: "Workshop", color: "#D97706" },
      { name: "Arts", color: "#059669" }
    ];
    
    categories.forEach(category => {
      this.createCategory(category);
    });
    
    // Initialize clubs
    const clubs: InsertClub[] = [
      { 
        name: "Coding Club", 
        description: "For coding enthusiasts to learn, collaborate and build amazing projects.",
        icon: "ri-code-box-line",
        backgroundColor: "#2563EB",
        memberCount: 120
      },
      { 
        name: "Cultural Club", 
        description: "Celebrating diversity through music, dance, and art performances.",
        icon: "ri-music-line",
        backgroundColor: "#9333EA",
        memberCount: 150
      },
      { 
        name: "Sports Club", 
        description: "Promoting physical activities and organizing sports competitions.",
        icon: "ri-basketball-line",
        backgroundColor: "#2563EB",
        memberCount: 180
      },
      { 
        name: "Photography Club", 
        description: "Capturing moments and sharing the art of photography.",
        icon: "ri-camera-line",
        backgroundColor: "#059669",
        memberCount: 90
      },
      { 
        name: "AI Society", 
        description: "Exploring the world of artificial intelligence and machine learning.",
        icon: "ri-robot-line",
        backgroundColor: "#D97706",
        memberCount: 75
      },
      { 
        name: "Debate Club", 
        description: "Improving oratory skills through debates and discussions.",
        icon: "ri-discuss-line",
        backgroundColor: "#DC2626",
        memberCount: 60
      }
    ];
    
    clubs.forEach(club => {
      this.createClub(club);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id, role: "student" };
    this.users.set(id, user);
    return user;
  }
  
  // Club operations
  async getClub(id: number): Promise<Club | undefined> {
    return this.clubs.get(id);
  }
  
  async getClubs(): Promise<Club[]> {
    return Array.from(this.clubs.values());
  }
  
  async createClub(insertClub: InsertClub): Promise<Club> {
    const id = this.clubIdCounter++;
    const club: Club = { ...insertClub, id };
    this.clubs.set(id, club);
    return club;
  }
  
  async updateClub(id: number, clubUpdate: Partial<Club>): Promise<Club | undefined> {
    const club = await this.getClub(id);
    if (!club) return undefined;
    
    const updatedClub = { ...club, ...clubUpdate };
    this.clubs.set(id, updatedClub);
    return updatedClub;
  }
  
  async deleteClub(id: number): Promise<void> {
    if (!this.clubs.has(id)) {
      throw new Error(`Club with id ${id} not found`);
    }
    
    // Delete the club
    this.clubs.delete(id);
    
    // Delete all memberships for this club
    const clubMemberships = Array.from(this.clubMemberships.values());
    for (const membership of clubMemberships) {
      if (membership.clubId === id) {
        const membershipId = Array.from(this.clubMemberships.entries())
          .find(([_, m]) => m.userId === membership.userId && m.clubId === id)?.[0];
          
        if (membershipId !== undefined) {
          this.clubMemberships.delete(membershipId);
        }
      }
    }
  }
  
  // Category operations
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }
  
  // Event operations
  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }
  
  async getEvents(filters?: Partial<Event>): Promise<Event[]> {
    let events = Array.from(this.events.values());
    
    if (filters) {
      events = events.filter(event => {
        for (const [key, value] of Object.entries(filters)) {
          if (event[key as keyof Event] !== value) {
            return false;
          }
        }
        return true;
      });
    }
    
    return events;
  }
  
  async getEventsByClub(clubId: number): Promise<Event[]> {
    return Array.from(this.events.values()).filter(
      (event) => event.clubId === clubId
    );
  }
  
  async getEventsByCategory(categoryId: number): Promise<Event[]> {
    return Array.from(this.events.values()).filter(
      (event) => event.categoryId === categoryId
    );
  }
  
  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = this.eventIdCounter++;
    const event: Event = { 
      ...insertEvent, 
      id, 
      registrationsCount: 0,
      status: insertEvent.status || "active" 
    };
    this.events.set(id, event);
    return event;
  }
  
  async updateEvent(id: number, eventUpdate: Partial<Event>): Promise<Event | undefined> {
    const event = await this.getEvent(id);
    if (!event) return undefined;
    
    const updatedEvent = { ...event, ...eventUpdate };
    this.events.set(id, updatedEvent);
    return updatedEvent;
  }
  
  async deleteEvent(id: number): Promise<void> {
    if (!this.events.has(id)) {
      throw new Error(`Event with id ${id} not found`);
    }
    
    this.events.delete(id);
  }
  
  // Registration operations
  async getRegistration(id: number): Promise<Registration | undefined> {
    return this.registrations.get(id);
  }
  
  async getRegistrationByUserAndEvent(userId: number, eventId: number): Promise<Registration | undefined> {
    return Array.from(this.registrations.values()).find(
      (registration) => registration.userId === userId && registration.eventId === eventId
    );
  }
  
  async getRegistrationsByUser(userId: number): Promise<Registration[]> {
    return Array.from(this.registrations.values()).filter(
      (registration) => registration.userId === userId
    );
  }
  
  async getRegistrationsByEvent(eventId: number): Promise<Registration[]> {
    return Array.from(this.registrations.values()).filter(
      (registration) => registration.eventId === eventId
    );
  }
  
  async createRegistration(insertRegistration: InsertRegistration): Promise<Registration> {
    const id = this.registrationIdCounter++;
    const registration: Registration = { 
      ...insertRegistration, 
      id, 
      paymentStatus: "pending",
      registrationDate: new Date(),
      transactionId: null
    };
    this.registrations.set(id, registration);
    
    // Update event registration count
    const event = await this.getEvent(insertRegistration.eventId);
    if (event) {
      await this.updateEvent(event.id, { 
        registrationsCount: event.registrationsCount + 1 
      });
    }
    
    return registration;
  }
  
  async updateRegistration(id: number, registrationUpdate: Partial<Registration>): Promise<Registration | undefined> {
    const registration = await this.getRegistration(id);
    if (!registration) return undefined;
    
    const updatedRegistration = { ...registration, ...registrationUpdate };
    this.registrations.set(id, updatedRegistration);
    return updatedRegistration;
  }
  
  // Club membership operations
  async getClubMembership(id: number): Promise<ClubMembership | undefined> {
    return this.clubMemberships.get(id);
  }
  
  async getClubMemberships(clubId: number): Promise<ClubMembership[]> {
    return Array.from(this.clubMemberships.values()).filter(
      (membership) => membership.clubId === clubId
    );
  }
  
  async getClubMembershipsByUser(userId: number): Promise<ClubMembership[]> {
    return Array.from(this.clubMemberships.values()).filter(
      (membership) => membership.userId === userId
    );
  }
  
  async createClubMembership(insertMembership: InsertClubMembership): Promise<ClubMembership> {
    const id = this.clubMembershipIdCounter++;
    const membership: ClubMembership = {
      ...insertMembership,
      id,
      role: insertMembership.role || "member", // Ensure role is never undefined
      joinDate: new Date()
    };
    this.clubMemberships.set(id, membership);
    
    // Update club member count
    const club = await this.getClub(insertMembership.clubId);
    if (club) {
      await this.updateClub(club.id, {
        memberCount: club.memberCount + 1
      });
    }
    
    return membership;
  }
  
  async deleteClubMembership(userId: number, clubId: number): Promise<void> {
    const membership = Array.from(this.clubMemberships.values()).find(
      (m) => m.userId === userId && m.clubId === clubId
    );
    
    if (membership) {
      this.clubMemberships.delete(membership.id);
      
      // Update club member count
      const club = await this.getClub(clubId);
      if (club && club.memberCount > 0) {
        await this.updateClub(club.id, {
          memberCount: club.memberCount - 1
        });
      }
    }
  }
  
  async getClubMembersDetails(clubId: number): Promise<{user: {id: number, username: string, fullName: string, email: string}, role: string, joinDate: Date}[]> {
    const memberships = await this.getClubMemberships(clubId);
    
    const memberDetails = [];
    for (const membership of memberships) {
      const user = await this.getUser(membership.userId);
      if (user) {
        memberDetails.push({
          user: {
            id: user.id,
            username: user.username,
            fullName: user.fullName,
            email: user.email
          },
          role: membership.role,
          joinDate: membership.joinDate
        });
      }
    }
    
    return memberDetails;
  }
}

export class DatabaseStorage implements IStorage {
  public sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
    // Initialize sample data
    this.initializeSampleData().catch(console.error);
  }

  private async initializeSampleData() {
    // Check if we already have categories
    const existingCategories = await this.getCategories();
    if (existingCategories.length === 0) {
      // Initialize categories
      const categories: InsertCategory[] = [
        { name: "Technology", color: "#2563EB" },
        { name: "Cultural", color: "#9333EA" },
        { name: "Sports", color: "#2563EB" },
        { name: "Academic", color: "#DC2626" },
        { name: "Workshop", color: "#D97706" },
        { name: "Arts", color: "#059669" }
      ];
      
      for (const category of categories) {
        await this.createCategory(category);
      }
    }
    
    // Check if we already have clubs
    const existingClubs = await this.getClubs();
    if (existingClubs.length === 0) {
      // Initialize clubs
      const clubs: InsertClub[] = [
        { 
          name: "Coding Club", 
          description: "For coding enthusiasts to learn, collaborate and build amazing projects.",
          icon: "ri-code-box-line",
          backgroundColor: "#2563EB",
          memberCount: 120
        },
        { 
          name: "Cultural Club", 
          description: "Celebrating diversity through music, dance, and art performances.",
          icon: "ri-music-line",
          backgroundColor: "#9333EA",
          memberCount: 150
        },
        { 
          name: "Sports Club", 
          description: "Promoting physical activities and organizing sports competitions.",
          icon: "ri-basketball-line",
          backgroundColor: "#2563EB",
          memberCount: 180
        },
        { 
          name: "Photography Club", 
          description: "Capturing moments and sharing the art of photography.",
          icon: "ri-camera-line",
          backgroundColor: "#059669",
          memberCount: 90
        },
        { 
          name: "AI Society", 
          description: "Exploring the world of artificial intelligence and machine learning.",
          icon: "ri-robot-line",
          backgroundColor: "#D97706",
          memberCount: 75
        },
        { 
          name: "Debate Club", 
          description: "Improving oratory skills through debates and discussions.",
          icon: "ri-discuss-line",
          backgroundColor: "#DC2626",
          memberCount: 60
        }
      ];
      
      for (const club of clubs) {
        await this.createClub(club);
      }
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values({
      ...insertUser,
      role: "student"
    }).returning();
    return result[0];
  }
  
  // Club operations
  async getClub(id: number): Promise<Club | undefined> {
    const result = await db.select().from(clubs).where(eq(clubs.id, id));
    return result[0];
  }
  
  async getClubs(): Promise<Club[]> {
    return await db.select().from(clubs);
  }
  
  async createClub(insertClub: InsertClub): Promise<Club> {
    const result = await db.insert(clubs).values(insertClub).returning();
    return result[0];
  }
  
  async updateClub(id: number, clubUpdate: Partial<Club>): Promise<Club | undefined> {
    const result = await db.update(clubs)
      .set(clubUpdate)
      .where(eq(clubs.id, id))
      .returning();
    return result[0];
  }
  
  async deleteClub(id: number): Promise<void> {
    // First verify the club exists
    const club = await this.getClub(id);
    if (!club) {
      throw new Error(`Club with id ${id} not found`);
    }
    
    // Delete all memberships for this club
    await db.delete(clubMemberships).where(eq(clubMemberships.clubId, id));
    
    // Delete all events for this club
    const clubEvents = await this.getEventsByClub(id);
    for (const event of clubEvents) {
      // Check if event has registrations
      const registrations = await this.getRegistrationsByEvent(event.id);
      if (registrations.length === 0) {
        // Only delete events without registrations
        await db.delete(events).where(eq(events.id, event.id));
      }
    }
    
    // Delete the club
    await db.delete(clubs).where(eq(clubs.id, id));
  }
  
  // Category operations
  async getCategory(id: number): Promise<Category | undefined> {
    const result = await db.select().from(categories).where(eq(categories.id, id));
    return result[0];
  }
  
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const result = await db.insert(categories).values(insertCategory).returning();
    return result[0];
  }
  
  // Event operations
  async getEvent(id: number): Promise<Event | undefined> {
    const result = await db.select().from(events).where(eq(events.id, id));
    return result[0];
  }
  
  async getEvents(filters?: Partial<Event>): Promise<Event[]> {
    if (!filters) {
      return await db.select().from(events);
    }
    
    let query = db.select().from(events);
    const filterEntries = Object.entries(filters);
    
    if (filterEntries.length > 0) {
      for (const [key, value] of filterEntries) {
        if (key in events) {
          query = query.where(eq(events[key as keyof typeof events], value));
        }
      }
    }
    
    return await query;
  }
  
  async getEventsByClub(clubId: number): Promise<Event[]> {
    return await db.select().from(events).where(eq(events.clubId, clubId));
  }
  
  async getEventsByCategory(categoryId: number): Promise<Event[]> {
    return await db.select().from(events).where(eq(events.categoryId, categoryId));
  }
  
  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const result = await db.insert(events).values({
      ...insertEvent,
      registrationsCount: 0,
      status: insertEvent.status || "active"
    }).returning();
    return result[0];
  }
  
  async updateEvent(id: number, eventUpdate: Partial<Event>): Promise<Event | undefined> {
    const result = await db.update(events)
      .set(eventUpdate)
      .where(eq(events.id, id))
      .returning();
    return result[0];
  }
  
  async deleteEvent(id: number): Promise<void> {
    // First verify the event exists
    const event = await this.getEvent(id);
    if (!event) {
      throw new Error(`Event with id ${id} not found`);
    }
    
    // Delete the event
    await db.delete(events).where(eq(events.id, id));
  }
  
  // Registration operations
  async getRegistration(id: number): Promise<Registration | undefined> {
    const result = await db.select().from(registrations).where(eq(registrations.id, id));
    return result[0];
  }
  
  async getRegistrationByUserAndEvent(userId: number, eventId: number): Promise<Registration | undefined> {
    const result = await db.select().from(registrations)
      .where(and(
        eq(registrations.userId, userId),
        eq(registrations.eventId, eventId)
      ));
    return result[0];
  }
  
  async getRegistrationsByUser(userId: number): Promise<Registration[]> {
    return await db.select().from(registrations).where(eq(registrations.userId, userId));
  }
  
  async getRegistrationsByEvent(eventId: number): Promise<Registration[]> {
    return await db.select().from(registrations).where(eq(registrations.eventId, eventId));
  }
  
  async createRegistration(insertRegistration: InsertRegistration): Promise<Registration> {
    const result = await db.insert(registrations).values({
      ...insertRegistration,
      paymentStatus: "pending",
      registrationDate: new Date(),
      transactionId: null
    }).returning();
    
    // Update event registration count
    const event = await this.getEvent(insertRegistration.eventId);
    if (event) {
      await this.updateEvent(event.id, { 
        registrationsCount: event.registrationsCount + 1 
      });
    }
    
    return result[0];
  }
  
  async updateRegistration(id: number, registrationUpdate: Partial<Registration>): Promise<Registration | undefined> {
    const result = await db.update(registrations)
      .set(registrationUpdate)
      .where(eq(registrations.id, id))
      .returning();
    return result[0];
  }
  
  // Club membership operations
  async getClubMembership(id: number): Promise<ClubMembership | undefined> {
    const result = await db.select().from(clubMemberships).where(eq(clubMemberships.id, id));
    return result[0];
  }
  
  async getClubMemberships(clubId: number): Promise<ClubMembership[]> {
    return await db.select().from(clubMemberships).where(eq(clubMemberships.clubId, clubId));
  }
  
  async getClubMembershipsByUser(userId: number): Promise<ClubMembership[]> {
    return await db.select().from(clubMemberships).where(eq(clubMemberships.userId, userId));
  }
  
  async createClubMembership(insertMembership: InsertClubMembership): Promise<ClubMembership> {
    const result = await db.insert(clubMemberships).values({
      ...insertMembership,
      role: insertMembership.role || "member", // Ensure role is never undefined
      joinDate: new Date()
    }).returning();
    
    // Update club member count
    const club = await this.getClub(insertMembership.clubId);
    if (club) {
      await this.updateClub(club.id, {
        memberCount: club.memberCount + 1
      });
    }
    
    return result[0];
  }
  
  async deleteClubMembership(userId: number, clubId: number): Promise<void> {
    // First find the membership
    const membership = await db.select().from(clubMemberships)
      .where(and(
        eq(clubMemberships.userId, userId),
        eq(clubMemberships.clubId, clubId)
      ));
    
    if (membership.length > 0) {
      // Delete the membership
      await db.delete(clubMemberships)
        .where(and(
          eq(clubMemberships.userId, userId),
          eq(clubMemberships.clubId, clubId)
        ));
      
      // Update club member count
      const club = await this.getClub(clubId);
      if (club && club.memberCount > 0) {
        await this.updateClub(club.id, {
          memberCount: club.memberCount - 1
        });
      }
    }
  }
  
  async getClubMembersDetails(clubId: number): Promise<{user: {id: number, username: string, fullName: string, email: string}, role: string, joinDate: Date}[]> {
    // Get all memberships for this club
    const memberships = await this.getClubMemberships(clubId);
    
    const memberDetails = [];
    for (const membership of memberships) {
      const user = await this.getUser(membership.userId);
      if (user) {
        memberDetails.push({
          user: {
            id: user.id,
            username: user.username,
            fullName: user.fullName,
            email: user.email
          },
          role: membership.role,
          joinDate: membership.joinDate
        });
      }
    }
    
    return memberDetails;
  }
}

// Export the database storage implementation
export const storage = new DatabaseStorage();
