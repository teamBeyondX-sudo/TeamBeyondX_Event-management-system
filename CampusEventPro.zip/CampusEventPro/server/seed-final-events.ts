import { db } from './db';
import { events, Event } from '@shared/schema';

async function seedFinalEvents() {
  console.log('Starting final batch of event seeding...');

  // Get current max event ID to ensure we don't have ID conflicts
  const existingEvents = await db.select().from(events);
  const maxId = Math.max(...existingEvents.map(e => e.id), 0);
  console.log(`Found ${existingEvents.length} existing events. Starting from ID ${maxId + 1}`);

  const finalEvents = [
    {
      title: "Robotics Competition",
      description: "Design, build, and program robots to complete challenging tasks and competitions.",
      date: new Date("2024-02-15"),
      time: "10:00 AM",
      location: "Engineering Building",
      price: 20,
      capacity: 40,
      image: "https://images.unsplash.com/photo-1561144257-e32e8ffc8909?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8cm9ib3RpY3N8ZW58MHx8MHx8fDA%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 1, // Coding Club
      categoryId: 1, // Technology
      highlights: ["Materials provided", "Great for beginners and experts", "Prizes for winners"]
    },
    {
      title: "Poetry Slam Night",
      description: "Express yourself through poetry, spoken word, and storytelling in this open-mic event.",
      date: new Date("2024-02-20"),
      time: "07:00 PM",
      location: "Student Center",
      price: 5,
      capacity: 70,
      image: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8N3x8cG9ldHJ5fGVufDB8fDB8fHww",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 2, // Cultural Club
      categoryId: 6, // Arts
      highlights: ["All poetry styles welcome", "Supportive atmosphere", "Complimentary refreshments"]
    },
    {
      title: "Swimming Competition",
      description: "Compete in various swimming events including freestyle, backstroke, breaststroke, and relay races.",
      date: new Date("2024-02-25"),
      time: "01:00 PM",
      location: "College Swimming Pool",
      price: 8,
      capacity: 50,
      image: "https://images.unsplash.com/photo-1519315901367-f34ff9154487?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c3dpbW1pbmclMjBjb21wZXRpdGlvbnxlbnwwfHwwfHx8MA%3D%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 3, // Sports Club
      categoryId: 3, // Sports
      highlights: ["All skill levels welcome", "Professional timekeeping", "Medals for winners"]
    },
    {
      title: "Portrait Photography Workshop",
      description: "Learn essential techniques for capturing stunning portraits with natural and artificial lighting.",
      date: new Date("2024-03-01"),
      time: "02:00 PM",
      location: "Photography Studio",
      price: 15,
      capacity: 25,
      image: "https://images.unsplash.com/photo-1533307383780-2d2c44799fca?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fHBvcnRyYWl0JTIwcGhvdG9ncmFwaHl8ZW58MHx8MHx8fDA%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 4, // Photography Club
      categoryId: 5, // Workshop
      highlights: ["Hands-on practice", "Model provided", "Portfolio-worthy shots"]
    },
    {
      title: "Blockchain and Cryptocurrency Seminar",
      description: "Introduction to blockchain technology, cryptocurrencies, and their potential applications.",
      date: new Date("2024-03-05"),
      time: "04:00 PM",
      location: "Lecture Hall A",
      price: 0,
      capacity: 100,
      image: "https://images.unsplash.com/photo-1631603090989-93f9ef6f9d80?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGJsb2NrY2hhaW58ZW58MHx8MHx8fDA%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 5, // AI Society
      categoryId: 4, // Academic
      highlights: ["Expert speakers", "Q&A session", "Networking opportunity"]
    },
    {
      title: "Mock Trial Competition",
      description: "Simulate courtroom proceedings and practice legal argumentation in this realistic mock trial event.",
      date: new Date("2024-03-10"),
      time: "09:00 AM",
      location: "Law Department",
      price: 10,
      capacity: 40,
      image: "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8N3x8dHJpYWwlMjBjb3VydHxlbnwwfHwwfHx8MA%3D%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 6, // Debate Club
      categoryId: 4, // Academic
      highlights: ["Real cases", "Feedback from law professors", "Best attorney award"]
    },
    {
      title: "Cybersecurity Challenge",
      description: "Test your cybersecurity skills through hacking challenges, cryptography puzzles, and CTF competitions.",
      date: new Date("2024-03-15"),
      time: "10:00 AM",
      location: "Online",
      price: 5,
      capacity: 80,
      image: "https://images.unsplash.com/photo-1614064641938-3bbee52942c7?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8Y3liZXJzZWN1cml0eXxlbnwwfHwwfHx8MA%3D%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 1, // Coding Club
      categoryId: 1, // Technology
      highlights: ["Beginner to advanced tracks", "Mentorship available", "Prizes for top performers"]
    },
    {
      title: "Film Festival",
      description: "Showcase of student-produced short films across various genres including documentary, drama, and animation.",
      date: new Date("2024-03-20"),
      time: "06:00 PM",
      location: "Campus Theater",
      price: 7,
      capacity: 200,
      image: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8ZmlsbSUyMGZlc3RpdmFsfGVufDB8fDB8fHww",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 2, // Cultural Club
      categoryId: 6, // Arts
      highlights: ["Audience choice award", "Director Q&A sessions", "Networking with industry professionals"]
    },
    {
      title: "Ultimate Frisbee Tournament",
      description: "Fun and competitive ultimate frisbee tournament for teams of 7 players.",
      date: new Date("2024-03-25"),
      time: "11:00 AM",
      location: "Sports Fields",
      price: 10,
      capacity: 140,
      image: "https://images.unsplash.com/photo-1591291621060-89264efbcb15?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dWx0aW1hdGUlMjBmcmlzYmVlfGVufDB8fDB8fHww",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 3, // Sports Club
      categoryId: 3, // Sports
      highlights: ["All skill levels welcome", "Team and individual awards", "Post-tournament barbecue"]
    },
    {
      title: "Astrophotography Night",
      description: "Learn to capture stunning images of stars, planets, and celestial events with your camera.",
      date: new Date("2024-03-30"),
      time: "08:00 PM",
      location: "Observatory",
      price: 12,
      capacity: 30,
      image: "https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YXN0cm9waG90b2dyYXBoeXxlbnwwfHwwfHx8MA%3D%3D",
      registrationsCount: 0,
      status: "upcoming",
      clubId: 4, // Photography Club
      categoryId: 6, // Arts
      highlights: ["Telescope access", "Technical guidance", "Best photo contest"]
    }
  ];

  console.log(`Inserting ${finalEvents.length} final events...`);

  try {
    for (const event of finalEvents) {
      await db.insert(events).values(event);
    }
    console.log('Final events seeded successfully!');
  } catch (error) {
    console.error('Error seeding final events:', error);
  }
}

// Run the seeding function
seedFinalEvents().catch(console.error);