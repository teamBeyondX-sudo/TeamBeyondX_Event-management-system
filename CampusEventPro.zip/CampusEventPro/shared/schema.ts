import { pgTable, text, serial, integer, timestamp, boolean, unique, primaryKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  role: text("role").notNull().default("student"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  phone: true,
});

// Club schema
export const clubs = pgTable("clubs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  backgroundColor: text("background_color").notNull(),
  memberCount: integer("member_count").notNull().default(0),
});

export const insertClubSchema = createInsertSchema(clubs).pick({
  name: true,
  description: true,
  icon: true,
  backgroundColor: true,
  memberCount: true,
});

// Club memberships schema
export const clubMemberships = pgTable("club_memberships", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  clubId: integer("club_id").notNull().references(() => clubs.id),
  joinDate: timestamp("join_date").notNull().defaultNow(),
  role: text("role").notNull().default("member"), // member, leader, etc.
}, (table) => {
  return {
    userClubUnique: unique().on(table.userId, table.clubId),
  }
});

export const insertClubMembershipSchema = createInsertSchema(clubMemberships).pick({
  userId: true,
  clubId: true,
  role: true,
});

// Category schema
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  color: text("color").notNull(),
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  name: true,
  color: true,
});

// Event schema
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  date: timestamp("date").notNull(),
  time: text("time").notNull(),
  location: text("location").notNull(),
  price: integer("price").notNull(),
  capacity: integer("capacity").notNull(),
  image: text("image").notNull(),
  status: text("status").notNull().default("active"),
  registrationsCount: integer("registrations_count").notNull().default(0),
  clubId: integer("club_id").notNull(),
  categoryId: integer("category_id").notNull(),
  highlights: text("highlights").array(),
});

// Create a custom insert schema for events that accepts string dates
export const insertEventSchema = createInsertSchema(events)
  .pick({
    title: true,
    description: true,
    time: true,
    location: true,
    price: true,
    capacity: true,
    image: true,
    status: true,
    clubId: true,
    categoryId: true,
    highlights: true,
  })
  .extend({
    // Accept either a Date object or an ISO date string
    date: z.string().or(z.date()),
  });

// Registration schema
export const registrations = pgTable("registrations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  eventId: integer("event_id").notNull(),
  teamName: text("team_name"),
  teamSize: integer("team_size").default(1),
  requirements: text("requirements"),
  paymentStatus: text("payment_status").notNull().default("pending"),
  registrationDate: timestamp("registration_date").notNull().defaultNow(),
  paymentAmount: integer("payment_amount").notNull(),
  transactionId: text("transaction_id"),
}, (table) => {
  return {
    userEventUnique: unique().on(table.userId, table.eventId),
  }
});

export const insertRegistrationSchema = createInsertSchema(registrations).pick({
  userId: true,
  eventId: true,
  teamName: true,
  teamSize: true,
  requirements: true,
  paymentAmount: true,
});

// Type definitions
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Club = typeof clubs.$inferSelect;
export type InsertClub = z.infer<typeof insertClubSchema>;

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;

export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;

export type Registration = typeof registrations.$inferSelect;
export type InsertRegistration = z.infer<typeof insertRegistrationSchema>;

export type ClubMembership = typeof clubMemberships.$inferSelect;
export type InsertClubMembership = z.infer<typeof insertClubMembershipSchema>;
