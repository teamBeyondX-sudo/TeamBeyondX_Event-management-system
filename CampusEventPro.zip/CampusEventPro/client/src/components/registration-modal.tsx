import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Event } from "@shared/schema";

type RegistrationModalProps = {
  event: Event & {
    club?: {
      name: string;
      icon: string;
    };
  };
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: (registrationId: number) => void;
};

const registrationSchema = z.object({
  teamName: z.string().min(2, "Team name must be at least 2 characters").max(50),
  teamSize: z.string().min(1, "Please select a team size"),
  requirements: z.string().optional(),
});

type RegistrationFormValues = z.infer<typeof registrationSchema>;

export default function RegistrationModal({ event, open, onOpenChange, onSuccess }: RegistrationModalProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<RegistrationFormValues>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      teamName: "",
      teamSize: "1",
      requirements: "",
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: RegistrationFormValues) => {
      const res = await apiRequest("POST", `/api/events/${event.id}/register`, {
        teamName: data.teamName,
        teamSize: parseInt(data.teamSize),
        requirements: data.requirements,
      });
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Registration successful",
        description: "You have successfully registered for this event.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/registrations"] });
      onSuccess(data.id);
      onOpenChange(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message || "Failed to register for this event.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    },
  });

  function onSubmit(data: RegistrationFormValues) {
    setIsSubmitting(true);
    registerMutation.mutate(data);
  }

  const formatPrice = (price: number) => {
    return price === 0 ? "Free" : `₹${price}`;
  };

  const calculateTax = (price: number) => {
    return price * 0.18;
  };

  const calculateTotal = (price: number) => {
    return price + calculateTax(price);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Event Registration</DialogTitle>
          <DialogDescription>
            Complete the form below to register for the event.
          </DialogDescription>
        </DialogHeader>

        <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 mb-6">
          <div className="flex items-start">
            <img 
              src={event.image} 
              alt={event.title} 
              className="w-20 h-20 object-cover rounded-lg" 
            />
            <div className="ml-4">
              <h4 className="font-poppins font-semibold">{event.title}</h4>
              <div className="text-sm text-gray-500 dark:text-gray-400 space-y-1 mt-1">
                <div className="flex items-center">
                  <i className="ri-calendar-line mr-2"></i>
                  <span>{new Date(event.date).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center">
                  <i className="ri-time-line mr-2"></i>
                  <span>{event.time}</span>
                </div>
                <div className="flex items-center font-medium text-primary">
                  <i className="ri-price-tag-3-line mr-2"></i>
                  <span>{formatPrice(event.price)} per participant</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="teamName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Team Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter your team name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="teamSize"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Team Size</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select team size" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="1">1 Member</SelectItem>
                      <SelectItem value="2">2 Members</SelectItem>
                      <SelectItem value="3">3 Members</SelectItem>
                      <SelectItem value="4">4 Members</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="requirements"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Additional Requirements</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Any specific requirements or accommodations needed"
                      className="resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {event.price > 0 && (
              <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mb-2">
                <h4 className="font-poppins font-semibold text-lg mb-3">Payment Summary</h4>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <span>Registration Fee</span>
                    <span>{formatPrice(event.price)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>GST (18%)</span>
                    <span>₹{calculateTax(event.price).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg pt-2 border-t border-gray-200 dark:border-gray-700">
                    <span>Total</span>
                    <span>₹{calculateTotal(event.price).toFixed(2)}</span>
                  </div>
                </div>
              </div>
            )}

            <DialogFooter>
              <Button 
                type="submit" 
                className="w-full" 
                disabled={isSubmitting}
              >
                {isSubmitting ? "Registering..." : event.price > 0 ? "Continue to Payment" : "Register Now"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
