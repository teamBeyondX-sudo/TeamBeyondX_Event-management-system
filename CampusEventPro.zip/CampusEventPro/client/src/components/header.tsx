import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useTheme } from "@/components/ui/theme-provider";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Moon,
  Sun,
  ChevronDown,
  User,
  Calendar,
  LogOut,
} from "lucide-react";

export default function Header() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { theme, setTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="sticky top-0 z-50 glass-nav">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-3">
          {/* Brainware University Logo */}
          <div className="flex items-center space-x-2">
            <div className="relative h-9 w-9 flex-shrink-0">
              {/* Animated gradient ring around logo */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-primary/70 to-secondary/70 blur-sm opacity-70"></div>
              
              {/* Logo with glass effect */}
              <div className="h-9 w-9 relative rounded-full flex items-center justify-center glass-card border border-white/10 shadow-lg">
                <span className="font-bold text-white text-xl">BU</span>
              </div>
            </div>
            <div className="flex flex-col items-start leading-none">
              <span className="text-base font-bold text-gradient">
                Brainware
              </span>
              <span className="text-xs text-foreground/70">
                University
              </span>
            </div>
          </div>

          {/* Navigation - Desktop */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link 
              href="/" 
              className={`font-medium relative group transition-colors ${location === '/' ? 'text-primary' : 'text-foreground/90'}`}
            >
              <span className="group-hover:text-primary transition-colors duration-200">Home</span>
              {location === '/' && (
                <span className="absolute -bottom-1.5 left-0 right-0 h-0.5 bg-primary rounded-full"></span>
              )}
              <span className="absolute -bottom-1.5 left-1/2 right-1/2 h-0.5 bg-primary rounded-full group-hover:left-0 group-hover:right-0 transition-all duration-300 ease-out"></span>
            </Link>
            
            <Link 
              href="/events"
              className={`font-medium relative group transition-colors ${location === '/events' ? 'text-primary' : 'text-foreground/90'}`}
            >
              <span className="group-hover:text-primary transition-colors duration-200">Events</span>
              {location === '/events' && (
                <span className="absolute -bottom-1.5 left-0 right-0 h-0.5 bg-primary rounded-full"></span>
              )}
              <span className="absolute -bottom-1.5 left-1/2 right-1/2 h-0.5 bg-primary rounded-full group-hover:left-0 group-hover:right-0 transition-all duration-300 ease-out"></span>
            </Link>
            
            <Link 
              href="/clubs"
              className={`font-medium relative group transition-colors ${location === '/clubs' ? 'text-primary' : 'text-foreground/90'}`}
            >
              <span className="group-hover:text-primary transition-colors duration-200">Clubs</span>
              {location === '/clubs' && (
                <span className="absolute -bottom-1.5 left-0 right-0 h-0.5 bg-primary rounded-full"></span>
              )}
              <span className="absolute -bottom-1.5 left-1/2 right-1/2 h-0.5 bg-primary rounded-full group-hover:left-0 group-hover:right-0 transition-all duration-300 ease-out"></span>
            </Link>
            
            {user && (
              <>
                <Link 
                  href="/my-registrations"
                  className={`font-medium relative group transition-colors ${location === '/my-registrations' ? 'text-primary' : 'text-foreground/90'}`}
                >
                  <span className="group-hover:text-primary transition-colors duration-200">My Registrations</span>
                  {location === '/my-registrations' && (
                    <span className="absolute -bottom-1.5 left-0 right-0 h-0.5 bg-primary rounded-full"></span>
                  )}
                  <span className="absolute -bottom-1.5 left-1/2 right-1/2 h-0.5 bg-primary rounded-full group-hover:left-0 group-hover:right-0 transition-all duration-300 ease-out"></span>
                </Link>
                
                <Link 
                  href="/my-clubs"
                  className={`font-medium relative group transition-colors ${location === '/my-clubs' ? 'text-primary' : 'text-foreground/90'}`}
                >
                  <span className="group-hover:text-primary transition-colors duration-200">My Clubs</span>
                  {location === '/my-clubs' && (
                    <span className="absolute -bottom-1.5 left-0 right-0 h-0.5 bg-primary rounded-full"></span>
                  )}
                  <span className="absolute -bottom-1.5 left-1/2 right-1/2 h-0.5 bg-primary rounded-full group-hover:left-0 group-hover:right-0 transition-all duration-300 ease-out"></span>
                </Link>
              </>
            )}
            
            {user && user.role === "admin" && (
              <Link 
                href="/admin"
                className="font-medium relative px-3 py-1.5 bg-secondary/10 text-secondary rounded-md hover:bg-secondary/20 transition-colors shadow-sm shadow-secondary/5"
              >
                Admin Dashboard
              </Link>
            )}
          </nav>

          {/* User Actions */}
          <div className="flex items-center space-x-4">
            {/* Theme Toggler */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              aria-label="Toggle theme"
            >
              {theme === "dark" ? (
                <Sun className="h-5 w-5" />
              ) : (
                <Moon className="h-5 w-5" />
              )}
            </Button>

            {/* User Menu - Not logged in */}
            {!user && (
              <Link href="/auth">
                <Button className="bg-primary text-white hover-glow btn-pulse">Sign In</Button>
              </Link>
            )}

            {/* User Menu - Logged in */}
            {user && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2 pr-2 pl-0">
                    <div className="relative">
                      {/* Animated gradient ring around avatar */}
                      <div className="absolute inset-0 rounded-full bg-gradient-to-r from-primary to-secondary via-pink-500 animate-gradient-xy blur-sm opacity-70"></div>
                      
                      {/* Inner avatar */}
                      <div className="h-9 w-9 relative rounded-full flex items-center justify-center glass-card border border-white/10 shadow-lg">
                        <span className="font-medium text-primary text-transparent bg-clip-text bg-gradient-to-br from-primary to-secondary">
                          {user.fullName.substring(0, 2).toUpperCase()}
                        </span>
                      </div>
                      
                      {/* Online indicator */}
                      <div className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-green-500 border border-background shadow-sm"></div>
                    </div>
                    <span className="font-medium hidden md:inline">
                      {user.fullName}
                    </span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem className="cursor-pointer">
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer">
                    <Link href="/my-registrations">
                      <div className="flex items-center w-full">
                        <Calendar className="mr-2 h-4 w-4" />
                        <span>My Events</span>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer">
                    <Link href="/my-clubs">
                      <div className="flex items-center w-full">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="mr-2 h-4 w-4"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                          />
                        </svg>
                        <span>My Clubs</span>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    className="cursor-pointer text-red-500" 
                    onClick={handleLogout}
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Sign Out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle menu"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            </Button>
          </div>
        </div>

        {/* Mobile Menu - updated to be more consistent with our design */}
        {mobileMenuOpen && (
          <div className="md:hidden pb-4 mt-2 glass-card p-4 rounded-lg border border-white/10 animate-in fade-in-50 slide-in-from-top-5 duration-200 backdrop-blur-lg">
            <div className="flex flex-col space-y-4">
              <Link 
                href="/"
                className={`font-medium flex items-center py-2 px-3 rounded-md transition-all ${location === '/' ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-primary/5'}`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
                Home
              </Link>
              <Link 
                href="/events"
                className={`font-medium flex items-center py-2 px-3 rounded-md transition-all ${location === '/events' ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-primary/5'}`}
              >
                <Calendar className="h-4 w-4 mr-2" />
                Events
              </Link>
              <Link 
                href="/clubs"
                className={`font-medium flex items-center py-2 px-3 rounded-md transition-all ${location === '/clubs' ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-primary/5'}`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
                Clubs
              </Link>
              
              {user && (
                <>
                  <div className="h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent my-1"></div>
                  <Link 
                    href="/my-registrations"
                    className={`font-medium flex items-center py-2 px-3 rounded-md transition-all ${location === '/my-registrations' ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-primary/5'}`}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                    </svg>
                    My Registrations
                  </Link>
                  <Link 
                    href="/my-clubs"
                    className={`font-medium flex items-center py-2 px-3 rounded-md transition-all ${location === '/my-clubs' ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-primary/5'}`}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                    My Clubs
                  </Link>
                </>
              )}
              
              {user && user.role === "admin" && (
                <Link 
                  href="/admin"
                  className="font-medium flex items-center py-2 px-3 rounded-md bg-secondary/10 text-secondary hover:bg-secondary/20 transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  Admin Dashboard
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
