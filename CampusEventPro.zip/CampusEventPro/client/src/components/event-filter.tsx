import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Filter } from "lucide-react";
import { Category } from "@shared/schema";

type EventFilterProps = {
  onFilterChange: (filters: {
    search?: string;
    categoryId?: number;
    clubId?: number;
  }) => void;
};

export default function EventFilter({ onFilterChange }: EventFilterProps) {
  const [activeCategory, setActiveCategory] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const handleCategoryClick = (categoryId: number | null) => {
    setActiveCategory(categoryId);
    onFilterChange({ 
      categoryId: categoryId ?? undefined,
      search: searchTerm || undefined
    });
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onFilterChange({ 
      categoryId: activeCategory ?? undefined,
      search: searchTerm || undefined
    });
  };

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      onFilterChange({ 
        categoryId: activeCategory ?? undefined,
        search: searchTerm || undefined
      });
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm]);

  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-8">
        <h2 className="font-poppins font-bold text-3xl">Upcoming Events</h2>
        <div className="flex items-center space-x-4">
          <form onSubmit={handleSearchSubmit} className="relative">
            <Input
              type="text"
              placeholder="Search events..."
              className="pl-10 pr-4 py-2 w-full md:w-64"
              value={searchTerm}
              onChange={handleSearchChange}
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          </form>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-4">
        <Button
          variant={activeCategory === null ? "default" : "outline"}
          className={activeCategory === null ? "bg-primary text-white" : "bg-gray-100 dark:bg-gray-800"}
          onClick={() => handleCategoryClick(null)}
        >
          All Events
        </Button>

        {categories?.map((category) => (
          <Button
            key={category.id}
            variant={activeCategory === category.id ? "default" : "outline"}
            className={
              activeCategory === category.id 
                ? "bg-primary text-white" 
                : "bg-gray-100 dark:bg-gray-800"
            }
            onClick={() => handleCategoryClick(category.id)}
          >
            {category.name}
          </Button>
        ))}
      </div>
    </div>
  );
}
