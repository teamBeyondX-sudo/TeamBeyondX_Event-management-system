import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";

export default function Footer() {
  const { user } = useAuth();
  return (
    <footer className="glass-nav border-t border-primary/10 text-foreground py-12 mt-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <div className="relative h-10 w-10 mr-2 flex-shrink-0">
                {/* Animated gradient ring around logo */}
                <div className="absolute inset-0 rounded-full bg-gradient-to-r from-primary/70 to-secondary/70 blur-sm opacity-70"></div>
                
                {/* Logo with glass effect */}
                <div className="h-10 w-10 relative rounded-full flex items-center justify-center glass-card border border-white/10 shadow-lg">
                  <span className="font-bold text-white text-xl">BU</span>
                </div>
              </div>
              <div>
                <h3 className="font-bold text-xl text-gradient">Brainware University</h3>
                <p className="text-xs text-foreground/70">Campus Events & Clubs</p>
              </div>
            </div>
            
            <p className="text-foreground/70 mb-4">
              Experience the vibrant campus life at Brainware University through our diverse clubs and exciting events.
            </p>
            
            <div className="flex space-x-4">
              <a
                href="https://www.facebook.com/BrainwareUniversity"
                target="_blank"
                rel="noopener noreferrer"
                className="text-foreground/60 hover:text-primary transition-colors"
                aria-label="Facebook"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z" />
                </svg>
              </a>
              <a
                href="https://twitter.com/BrainwareUni"
                target="_blank"
                rel="noopener noreferrer"
                className="text-foreground/60 hover:text-primary transition-colors"
                aria-label="Twitter"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z" />
                </svg>
              </a>
              <a
                href="https://www.instagram.com/brainware_university/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-foreground/60 hover:text-primary transition-colors"
                aria-label="Instagram"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                </svg>
              </a>
              <a
                href="https://www.linkedin.com/school/brainware-university/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-foreground/60 hover:text-primary transition-colors"
                aria-label="LinkedIn"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z" />
                </svg>
              </a>
              <a
                href="https://www.youtube.com/c/BrainwareUniversity"
                target="_blank"
                rel="noopener noreferrer"
                className="text-foreground/60 hover:text-primary transition-colors"
                aria-label="YouTube"
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-5 w-5" 
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
                </svg>
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-4 text-foreground">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <span className="text-foreground/70 hover:text-primary transition-colors cursor-pointer">
                    Home
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/events">
                  <span className="text-foreground/70 hover:text-primary transition-colors cursor-pointer">
                    Events
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/clubs">
                  <span className="text-foreground/70 hover:text-primary transition-colors cursor-pointer">
                    Clubs
                  </span>
                </Link>
              </li>
              <li>
                <span className="text-foreground/70 hover:text-primary transition-colors cursor-pointer">
                  About Us
                </span>
              </li>
              <li>
                <span className="text-foreground/70 hover:text-primary transition-colors cursor-pointer">
                  Contact
                </span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-4 text-foreground">For Organizers</h4>
            <ul className="space-y-2">
              {/* Only show admin links to admin users */}
              {user?.role === "admin" && (
                <>
                  <li>
                    <Link href="/create-club">
                      <span className="text-foreground/70 hover:text-primary transition-colors cursor-pointer">
                        Create Club
                      </span>
                    </Link>
                  </li>
                  <li>
                    <Link href="/create-event">
                      <span className="text-foreground/70 hover:text-primary transition-colors cursor-pointer">
                        Organize Event
                      </span>
                    </Link>
                  </li>
                  <li>
                    <Link href="/admin">
                      <span className="text-foreground/70 hover:text-primary transition-colors cursor-pointer">
                        Admin Dashboard
                      </span>
                    </Link>
                  </li>
                </>
              )}
              <li>
                <span className="text-foreground/70 hover:text-primary transition-colors cursor-pointer">
                  Resources
                </span>
              </li>
              <li>
                <span className="text-foreground/70 hover:text-primary transition-colors cursor-pointer">
                  Guidelines
                </span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-4 text-foreground">Contact Us</h4>
            <ul className="space-y-2">
              <li className="flex items-start group">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 mt-1 mr-2 text-primary/70 group-hover:text-primary transition-colors"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
                <span className="text-foreground/70 group-hover:text-foreground transition-colors">
                  398, Ramkrishnapur Road, Barasat, Kolkata - 700125, West Bengal
                </span>
              </li>
              <li className="flex items-center group">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 mr-2 text-primary/70 group-hover:text-primary transition-colors"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                  />
                </svg>
                <a
                  href="mailto:info@brainwareuniversity.ac.in"
                  className="text-foreground/70 hover:text-primary transition-colors"
                >
                  info@brainwareuniversity.ac.in
                </a>
              </li>
              <li className="flex items-center group">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 mr-2 text-primary/70 group-hover:text-primary transition-colors"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                  />
                </svg>
                <a
                  href="tel:+913325842428"
                  className="text-foreground/70 hover:text-primary transition-colors"
                >
                  +91 33-2584-2428
                </a>
              </li>
              <li className="flex items-center group mt-3">
                <div className="glass-card px-3 py-1 rounded-full border border-primary/10 text-xs">
                  <span className="text-foreground/90">Est. 2016</span>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary/10 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-foreground/70 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} Brainware University. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <a
              href="https://www.brainwareuniversity.ac.in/privacy-policy.php"
              target="_blank"
              rel="noopener noreferrer"
              className="text-foreground/70 text-sm hover:text-primary transition-colors"
            >
              Privacy Policy
            </a>
            <a
              href="https://www.brainwareuniversity.ac.in/terms-of-use.php"
              target="_blank"
              rel="noopener noreferrer"
              className="text-foreground/70 text-sm hover:text-primary transition-colors"
            >
              Terms of Use
            </a>
            <a
              href="https://www.brainwareuniversity.ac.in/contact-us.php"
              target="_blank"
              rel="noopener noreferrer"
              className="text-foreground/70 text-sm hover:text-primary transition-colors"
            >
              Contact
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
