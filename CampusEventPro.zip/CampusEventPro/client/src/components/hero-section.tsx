import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Calendar, Users, GraduationCap, ExternalLink } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden py-36 md:py-44">
      {/* No overlay - allowing Spline 3D background to show through clearly */}
      
      {/* Content container with higher contrast elements */}
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col items-center text-center max-w-5xl mx-auto">
          {/* University branding with enhanced styling */}
          <div className="mb-8 flex items-center justify-center">
            <div className="bg-primary/20 backdrop-blur-sm p-3 rounded-full mr-4">
              <GraduationCap className="text-white h-8 w-8" />
            </div>
            <h2 className="text-white text-2xl font-medium tracking-wide">Brainware University</h2>
          </div>
          
          {/* Main heading with enhanced typography and no blur background */}
          <div className="space-y-8 mb-12">
            <h1 className="font-extrabold text-5xl md:text-7xl tracking-tight leading-tight">
              <span className="text-gradient animate-gradient-xy block mb-3">Campus Life</span> 
              <span className="text-white">Events & Communities</span>
            </h1>
            
            {/* Larger subtitle with glass effect but reduced blur */}
            <div className="glass-card p-8 max-w-2xl mx-auto rounded-2xl border border-white/10 backdrop-blur-md">
              <p className="text-xl md:text-2xl text-white/95 leading-relaxed">
                Discover and participate in Brainware University's vibrant campus events, join student clubs, and embrace a richer educational journey.
              </p>
            </div>
            
            {/* Call to action buttons with enhanced design - removed backdrop blur */}
            <div className="flex flex-col sm:flex-row justify-center gap-6 mt-10">
              <Link href="/events">
                <Button size="lg" className="bg-primary text-white hover-glow btn-pulse text-lg px-10 py-7 h-auto rounded-xl group">
                  Explore Events
                  <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                </Button>
              </Link>
              <Link href="/clubs">
                <Button size="lg" variant="outline" className="border-2 border-white/50 text-white hover:bg-white/10 text-lg px-10 py-7 h-auto rounded-xl">
                  Browse Clubs
                </Button>
              </Link>
            </div>
          </div>
          
          {/* Stats with enhanced glass effect */}
          <div className="flex flex-col md:flex-row items-center justify-center gap-6 mt-12">
            <div className="glass-card py-5 px-8 rounded-full flex items-center">
              <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center mr-4">
                <Users className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl text-white font-medium">50+ Active Clubs</span>
            </div>
            <div className="glass-card py-5 px-8 rounded-full flex items-center">
              <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center mr-4">
                <Calendar className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl text-white font-medium">200+ Events Monthly</span>
            </div>
          </div>
          
          {/* Enhanced university details with link */}
          <div className="mt-16 glass-card py-3 px-6 rounded-full flex items-center">
            <span className="text-sm text-white/90 font-medium mr-2">Est. 2016 • Barasat, West Bengal</span>
            <a 
              href="https://www.brainwareuniversity.ac.in" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary flex items-center hover:underline"
            >
              <ExternalLink className="h-3 w-3 ml-1" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
