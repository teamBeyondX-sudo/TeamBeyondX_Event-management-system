import { ReactNode } from "react";
import Header from "./header";
import Footer from "./footer";
import SplineDirect from "./spline-direct";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="flex flex-col min-h-screen relative force-gpu">
      {/* 3D Background with Spline - now continuous across all pages */}
      <SplineDirect />
      
      {/* Content overlay with better positioning relative to background */}
      <div className="relative z-10 flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow page-content">
          {children}
        </main>
        <Footer />
      </div>
    </div>
  );
}
