import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CalendarIcon, Clock, MapPin } from "lucide-react";
import { format } from "date-fns";
import { Event } from "@shared/schema";

type EventCardProps = {
  event: Event & {
    club?: {
      name: string;
      icon: string;
      backgroundColor: string;
    };
    category?: {
      name: string;
      color: string;
    };
  };
  onClick?: () => void;
  onRegister?: (e: React.MouseEvent) => void;
};

export default function EventCard({ event, onClick, onRegister }: EventCardProps) {
  const formatPrice = (price: number) => {
    return price === 0 ? "Free" : `₹${price}`;
  };

  const getStatusBadge = () => {
    if (event.registrationsCount >= event.capacity) {
      return (
        <Badge className="bg-black/40 backdrop-blur-sm text-white border-amber-500 border-[1px]">
          Full
        </Badge>
      );
    }
    
    if (event.status === "upcoming") {
      return (
        <Badge className="bg-black/40 backdrop-blur-sm text-white border-green-500 border-[1px]">
          Upcoming
        </Badge>
      );
    }
    
    if (event.status === "closed") {
      return (
        <Badge className="bg-black/40 backdrop-blur-sm text-white border-red-500 border-[1px]">
          Closed
        </Badge>
      );
    }
    
    if (event.status === "draft") {
      return (
        <Badge className="bg-black/40 backdrop-blur-sm text-white border-amber-500 border-[1px]">
          Draft
        </Badge>
      );
    }
    
    return (
      <Badge className="bg-black/40 backdrop-blur-sm text-white border-blue-500 border-[1px]">
        {event.status}
      </Badge>
    );
  };

  const handleCardClick = () => {
    if (onClick) {
      onClick();
    }
  };

  const handleRegisterClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onRegister) {
      onRegister(e);
    }
  };

  return (
    <Card 
      className="overflow-hidden hover-card cursor-pointer border border-primary/10 glass-card"
      onClick={handleCardClick}
    >
      <div className="relative h-52 group overflow-hidden">
        {/* Enhance image with overlay effects */}
        <img 
          src={event.image} 
          alt={event.title} 
          className="w-full h-full object-cover transition-all duration-500 group-hover:scale-110 group-hover:rotate-1"
        />
        
        {/* Multiple gradient overlays for depth */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent opacity-60"></div>
        
        {/* Animated glow effect on hover */}
        <div className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/20 to-primary/0 opacity-0 group-hover:opacity-30 blur-xl transition-opacity duration-700"></div>
        
        {/* Category badge with special styling */}
        <div className="absolute top-4 left-4">
          {event.category && (
            <Badge
              className="text-white font-medium backdrop-blur-sm bg-black/40 border-white/10 shadow-lg shadow-black/20"
              style={{ 
                borderLeft: `3px solid ${event.category.color}`
              }}
            >
              {event.category.name}
            </Badge>
          )}
        </div>
        
        {/* Price badge with glow effect */}
        <div className="absolute top-4 right-4">
          <Badge className="bg-primary text-white font-medium backdrop-blur-md shadow-lg shadow-primary/20 group-hover:shadow-primary/40 transition-all duration-300">
            {formatPrice(event.price)}
          </Badge>
        </div>
        
        {/* Date and status at bottom */}
        <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
          <span className="text-sm text-white flex items-center backdrop-blur-sm bg-black/20 py-1 px-2 rounded-full">
            <CalendarIcon className="mr-1 h-4 w-4 text-primary/80" /> 
            {format(new Date(event.date), "MMM d, yyyy")} • {event.time}
          </span>
          {getStatusBadge()}
        </div>
      </div>
      <CardContent className="p-6">
        {/* Title with gradient highlight on hover */}
        <div className="group/title">
          <h3 className="font-semibold text-xl mb-3 text-foreground group-hover/title:text-transparent group-hover/title:bg-clip-text group-hover/title:bg-gradient-to-r group-hover/title:from-primary group-hover/title:to-secondary transition-all duration-300">
            {event.title}
          </h3>
        </div>
        
        {/* Description with subtle highlight */}
        <p className="text-foreground/70 text-sm mb-4 line-clamp-2 group-hover:text-foreground/90 transition-colors duration-300">
          {event.description}
        </p>
        
        {/* Location indicator */}
        <div className="flex items-center mb-4 text-xs text-foreground/50">
          <MapPin className="h-3 w-3 mr-1 text-primary/70" />
          <span>{event.location}</span>
        </div>
        
        {/* Footer with club info and register button */}
        <div className="flex items-center justify-between mt-auto pt-2 border-t border-primary/10">
          {event.club && (
            <div className="flex items-center">
              <div 
                className="h-8 w-8 rounded-full flex items-center justify-center text-white shadow-md shadow-black/20"
                style={{ 
                  backgroundColor: event.club.backgroundColor,
                  backgroundImage: `radial-gradient(circle at 30% 107%, ${event.club.backgroundColor} 0%, rgba(0,0,0,0.5) 80%)` 
                }}
              >
                <i className={`${event.club.icon} text-sm`}></i>
              </div>
              <span className="ml-2 text-sm font-medium">{event.club.name}</span>
            </div>
          )}
          <Button 
            className={event.status === "upcoming" ? "bg-primary hover:bg-primary/90 text-white btn-pulse" : "bg-muted text-muted-foreground"}
            onClick={handleRegisterClick}
            disabled={event.registrationsCount >= event.capacity || event.status !== "upcoming"}
          >
            {event.status === "upcoming" ? "Register Now" : "Closed"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
