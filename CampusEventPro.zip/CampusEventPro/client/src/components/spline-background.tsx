import { useEffect, useRef } from 'react';

export default function SplineBackground() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Only run this effect once and on client-side
    if (typeof window === 'undefined' || !containerRef.current) return;
    
    // Check if viewer already exists
    if (containerRef.current.querySelector('spline-viewer')) return;
    
    // Create the spline viewer element directly
    const viewer = document.createElement('spline-viewer');
    
    // Set the Spline scene URL
    viewer.setAttribute('url', 'https://prod.spline.design/8sXxwYGhjEC2DDv7/scene.splinecode');
    
    // Set styling for fullscreen background
    viewer.style.width = '100%';
    viewer.style.height = '100%';
    viewer.style.position = 'absolute';
    viewer.style.top = '0';
    viewer.style.left = '0';
    viewer.style.zIndex = '-1';
    viewer.style.pointerEvents = 'none'; // Prevent capturing mouse events
    
    // Optimize performance
    viewer.setAttribute('loading-anim', 'true');
    viewer.setAttribute('background-color', 'transparent');
    viewer.setAttribute('ambient-light', '0.1');
    viewer.setAttribute('pixel-ratio', '1');
    viewer.setAttribute('shadow-quality', '0');
    viewer.setAttribute('hide-ui', 'true');
    
    // Add to container
    containerRef.current.appendChild(viewer);
    
    // Set a custom attribute to mark this is for Brainware University
    viewer.setAttribute('data-institution', 'brainware-university');
    
    return () => {
      // Cleanup if component unmounts
      if (containerRef.current && viewer) {
        try {
          containerRef.current.removeChild(viewer);
        } catch (e) {
          console.error('Error removing Spline viewer:', e);
        }
      }
    };
  }, []);

  return (
    <div 
      ref={containerRef} 
      className="fixed inset-0 z-[-1] pointer-events-none force-gpu"
      aria-hidden="true"
      data-testid="spline-background-container"
    />
  );
}