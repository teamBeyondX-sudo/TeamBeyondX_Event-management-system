import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

type PaymentModalProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  registrationId: number;
  amount: number;
  onSuccess: () => void;
};

export default function PaymentModal({ open, onOpenChange, registrationId, amount, onSuccess }: PaymentModalProps) {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [upiId, setUpiId] = useState("");

  const paymentMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/registrations/${registrationId}/payment`, {
        upiId: upiId || undefined,
      });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Payment successful",
        description: "Your payment has been processed successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/registrations"] });
      onSuccess();
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Payment failed",
        description: error.message || "Failed to process payment.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsProcessing(false);
    },
  });

  const handlePayment = () => {
    setIsProcessing(true);
    paymentMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[450px] glass-card border-primary/10">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold flex items-center justify-center">
            <div className="relative mr-3">
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-primary to-secondary animate-gradient-xy blur-sm opacity-70"></div>
              <div className="h-9 w-9 relative rounded-full flex items-center justify-center glass-card border border-white/10 shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="h-5 w-5">
                  <path fill="#5F259F" d="M24 4C13 4 4 13 4 24s9 20 20 20 20-9 20-20S35 4 24 4zm-.3 23.4c-1.4 0-2.5-1.1-2.5-2.5s1.1-2.5 2.5-2.5 2.5 1.1 2.5 2.5-1.1 2.5-2.5 2.5z" />
                  <path fill="#FFF" d="M23.7 18.4c-3.6 0-6.5 2.9-6.5 6.5s2.9 6.5 6.5 6.5 6.5-2.9 6.5-6.5-2.9-6.5-6.5-6.5zm0 9c-1.4 0-2.5-1.1-2.5-2.5s1.1-2.5 2.5-2.5 2.5 1.1 2.5 2.5-1.1 2.5-2.5 2.5z" />
                </svg>
              </div>
            </div>
            <span className="text-gradient">PhonePe Payment</span>
          </DialogTitle>
          <DialogDescription className="text-center text-foreground/70">
            Scan the QR code below to complete your payment
          </DialogDescription>
        </DialogHeader>

        <div className="text-center mb-6">
          <div className="relative group p-1 inline-block rounded-xl bg-gradient-to-r from-primary/30 to-secondary/30 shimmer">
            <div className="bg-background p-4 rounded-lg">
              <div className="w-64 mx-auto mb-2">
                <img 
                  src="/assets/phonepe_qr.jpg" 
                  alt="PhonePe QR Code" 
                  className="w-full h-auto rounded-md shadow-md"
                />
              </div>
            </div>
            <div className="absolute inset-0 blur-md bg-gradient-to-r from-primary/0 via-primary/40 to-primary/0 opacity-0 group-hover:opacity-30 transition-opacity duration-700 rounded-xl"></div>
          </div>
          
          <div className="mt-4 bg-primary/5 border border-primary/20 rounded-lg p-3 inline-block">
            <p className="font-medium text-primary">Scan & Pay Using PhonePe App</p>
            <p className="text-xl font-bold mt-2 text-gradient">₹{amount.toFixed(2)}</p>
            <p className="text-xs text-foreground/70 mt-1">To: Akinchan Maji</p>
          </div>
        </div>

        <div className="mb-6">
          <div className="grid grid-cols-4 gap-3">
            {/* Payment method options */}
            <div className="flex flex-col items-center group cursor-pointer">
              <div className="bg-black/30 backdrop-blur-sm border border-white/5 p-3 rounded-xl mb-2 shadow-md group-hover:shadow-lg group-hover:shadow-primary/10 transition-all duration-300">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="h-8 w-8">
                  <path fill="#5F259F" d="M24 4C13 4 4 13 4 24s9 20 20 20 20-9 20-20S35 4 24 4zm-.3 23.4c-1.4 0-2.5-1.1-2.5-2.5s1.1-2.5 2.5-2.5 2.5 1.1 2.5 2.5-1.1 2.5-2.5 2.5z" />
                  <path fill="#FFF" d="M23.7 18.4c-3.6 0-6.5 2.9-6.5 6.5s2.9 6.5 6.5 6.5 6.5-2.9 6.5-6.5-2.9-6.5-6.5-6.5zm0 9c-1.4 0-2.5-1.1-2.5-2.5s1.1-2.5 2.5-2.5 2.5 1.1 2.5 2.5-1.1 2.5-2.5 2.5z" />
                </svg>
              </div>
              <span className="text-xs text-foreground/90 font-medium">PhonePe</span>
            </div>
            
            <div className="flex flex-col items-center group cursor-pointer">
              <div className="bg-black/30 backdrop-blur-sm border border-white/5 p-3 rounded-xl mb-2 shadow-md group-hover:shadow-lg group-hover:shadow-primary/10 transition-all duration-300">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="h-8 w-8">
                  <path fill="#FFD400" d="M24 44a6 6 0 006-6v-6h-6c-3.3 0-6 2.7-6 6s2.7 6 6 6z" />
                  <path fill="#4285F4" d="M42 22a6 6 0 00-6-6h-6v6c0 3.3 2.7 6 6 6s6-2.7 6-6z" />
                  <path fill="#109D59" d="M24 10a6 6 0 01-6 6h-6v-6c0-3.3 2.7-6 6-6s6 2.7 6 6z" />
                  <path fill="#D94F3D" d="M24 32a6 6 0 01-6-6v-6h6c3.3 0 6 2.7 6 6s-2.7 6-6 6z" />
                </svg>
              </div>
              <span className="text-xs text-foreground/70">Google Pay</span>
            </div>
            
            <div className="flex flex-col items-center group cursor-pointer">
              <div className="bg-black/30 backdrop-blur-sm border border-white/5 p-3 rounded-xl mb-2 shadow-md group-hover:shadow-lg group-hover:shadow-primary/10 transition-all duration-300">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="h-8 w-8">
                  <path fill="#01BAF2" d="M24 4C12.95 4 4 12.95 4 24s8.95 20 20 20 20-8.95 20-20S35.05 4 24 4z" />
                  <path fill="#FFF" d="M30.14 21.47c-.28-.28-.73-.28-1.01 0l-5.13 5.13-5.13-5.13c-.28-.28-.73-.28-1.01 0-.28.28-.28.73 0 1.01l5.13 5.13-5.13 5.13c-.28.28-.28.73 0 1.01.28.28.73.28 1.01 0l5.13-5.13 5.13 5.13c.28.28.73.28 1.01 0 .28-.28.28-.73 0-1.01l-5.13-5.13 5.13-5.13c.28-.28.28-.73 0-1.01z" />
                </svg>
              </div>
              <span className="text-xs text-foreground/70">Paytm</span>
            </div>
            
            <div className="flex flex-col items-center group cursor-pointer">
              <div className="bg-black/30 backdrop-blur-sm border border-white/5 p-3 rounded-xl mb-2 shadow-md group-hover:shadow-lg group-hover:shadow-primary/10 transition-all duration-300">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="h-8 w-8">
                  <path fill="#097939" d="M21.95 11.67c.21-.87.23-1.77.05-2.63l-2.89 1.71-1.13-1.97 2.89-1.71c-.63-.64-1.4-1.14-2.27-1.45l-1.06 3.1-2.19-.76 1.06-3.1c-.88-.03-1.75.14-2.56.49l.77 3.19L13 7.6l-.77-3.2c-.83.45-1.54 1.06-2.08 1.81l2.45 2.11-1.61 1.87-2.45-2.1c-.37.86-.56 1.78-.56 2.71v.19l3.2.42v2.28l-3.2.42c.09.89.38 1.76.84 2.54l2.8-1.62 1.11 1.98-2.8 1.62c.69.6 1.5 1.04 2.4 1.28l.42-3.16 2.26.3-.41 3.15c.89-.08 1.76-.35 2.53-.8l-1.09-3.09 2.09-.73 1.09 3.09c.82-.54 1.5-1.25 1.99-2.08l-2.73-1.77 1.28-1.97 2.73 1.78z" />
                </svg>
              </div>
              <span className="text-xs text-foreground/70">UPI</span>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <p className="text-center font-medium mb-3 text-foreground/90">Or pay using UPI ID</p>
          <div className="flex space-x-2">
            <Input
              type="text"
              placeholder="Enter UPI ID (e.g., name@upi)"
              value={upiId}
              onChange={(e) => setUpiId(e.target.value)}
              className="glass-card border-primary/20"
            />
            <Button 
              variant="outline" 
              className="shrink-0 border-primary hover:bg-primary/10 text-primary"
            >
              Verify
            </Button>
          </div>
        </div>

        <div className="text-sm text-foreground/60 mb-4 text-center bg-primary/5 rounded-lg p-3 border border-primary/10">
          <p className="flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Payment will be automatically verified once completed
          </p>
        </div>

        <DialogFooter>
          <Button
            onClick={handlePayment}
            className="w-full bg-primary hover:bg-primary/90 text-white hover-glow btn-pulse"
            disabled={isProcessing}
          >
            {isProcessing ? "Processing..." : "I've completed the payment"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
