import React, { useEffect, useRef } from 'react';

// Enhanced SplineDirect component with global state management to ensure continuity
export default function SplineDirect() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    
    // Only add the element if it doesn't already exist
    if (!containerRef.current.querySelector('spline-viewer')) {
      // Track if Spline was already initialized in window object to avoid recreating
      const wasInitialized = (window as any).__splineInitialized;
      
      if (!wasInitialized) {
        (window as any).__splineInitialized = true;
        
        // Create HTML for the spline-viewer element with enhanced settings
        containerRef.current.innerHTML = `
          <spline-viewer 
            url="https://prod.spline.design/8sXxwYGhjEC2DDv7/scene.splinecode"
            style="width: 100%; height: 100%; position: fixed; top: 0; left: 0; z-index: -1;"
            background-color="transparent"
            ambient-light="0.2"
            pixel-ratio="1"
            shadow-quality="0"
            environment-reflection-quality="0"
            hide-ui="true"
            loading-anim="true" 
            auto-rotate="false"
            camera-orbit="0 deg 0deg 150%"
            camera-control="false"
            data-institution="brainware-university">
          </spline-viewer>
        `;
      } else {
        // If already initialized elsewhere, create a reference div
        containerRef.current.innerHTML = `
          <div id="spline-reference" style="display:none;" data-initialized="true"></div>
        `;
      }
    }
    
    return () => {
      // Only remove if this is the main instance
      if (containerRef.current && !(window as any).__splineRemoving) {
        // Set a flag to prevent multiple removals
        (window as any).__splineRemoving = true;
        
        // Don't actually remove, just hide
        const viewer = containerRef.current.querySelector('spline-viewer');
        if (viewer) {
          viewer.setAttribute('style', 'display: none;');
        }
        
        // Reset flag after a delay
        setTimeout(() => {
          (window as any).__splineRemoving = false;
        }, 500);
      }
    };
  }, []);

  return (
    <>
      {/* Enhanced fallback background with more sophistication */}
      <div 
        className="fixed inset-0 z-[-2] pointer-events-none" 
        style={{
          background: 'radial-gradient(circle at bottom right, rgba(147, 51, 234, 0.15), rgba(0, 0, 0, 0.7) 80%)',
          backgroundBlendMode: 'normal',
        }}
      />
      
      {/* Container for Spline viewer with force-gpu class for better performance */}
      <div 
        ref={containerRef}
        className="fixed inset-0 z-[-1] pointer-events-none overflow-hidden force-gpu"
        aria-hidden="true"
        data-testid="spline-container"
      ></div>
    </>
  );
}