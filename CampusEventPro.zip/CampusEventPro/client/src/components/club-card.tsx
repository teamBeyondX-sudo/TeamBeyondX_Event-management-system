import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserIcon } from "lucide-react";
import { Club } from "@shared/schema";

type ClubCardProps = {
  club: Club;
  onClick?: () => void;
};

export default function ClubCard({ club, onClick }: ClubCardProps) {
  return (
    <Card 
      className="overflow-hidden hover-card cursor-pointer border border-primary/10 glass-card"
      onClick={onClick}
    >
      <div 
        className="h-44 flex items-center justify-center relative group overflow-hidden"
        style={{ 
          backgroundColor: club.backgroundColor,
          backgroundImage: `radial-gradient(circle at 50% 0%, ${club.backgroundColor}, rgba(0,0,0,0.7) 100%)`,
        }}
      >
        {/* Overlay pattern */}
        <div className="absolute inset-0 opacity-20 bg-grid-pattern"></div>
        
        {/* Animated glow effect on hover */}
        <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-700"></div>
        
        {/* Main icon with animation */}
        <div className="relative z-10 bg-black/30 p-8 rounded-full backdrop-blur-sm border border-white/10 shadow-xl transform transition-all duration-500 group-hover:scale-110 group-hover:shadow-[0_0_30px_rgba(255,255,255,0.2)]">
          <i className={`${club.icon} text-white text-5xl`}></i>
        </div>
        
        {/* Member count badge */}
        <div className="absolute bottom-4 right-4">
          <div className="flex items-center px-3 py-1 rounded-full bg-black/40 backdrop-blur-sm text-white text-xs border border-white/10 shadow">
            <UserIcon className="h-3 w-3 mr-1 text-primary/80" /> 
            <span>{club.memberCount}+ members</span>
          </div>
        </div>
      </div>
      
      <CardContent className="p-6">
        {/* Club name with gradient effect on hover */}
        <div className="group/title">
          <h3 className="font-semibold text-xl mb-2 text-foreground group-hover/title:text-transparent group-hover/title:bg-clip-text group-hover/title:bg-gradient-to-r group-hover/title:from-primary group-hover/title:to-secondary transition-all duration-300">
            {club.name}
          </h3>
        </div>
        
        {/* Description with subtle improvement */}
        <p className="text-foreground/70 text-sm mb-5 line-clamp-2 group-hover:text-foreground/90 transition-colors duration-300">
          {club.description}
        </p>
        
        {/* Action button with animation */}
        <Button 
          variant="outline" 
          className="w-full border-primary/40 text-primary hover:bg-primary/10 hover-glow btn-pulse shadow-sm"
        >
          View Club Details
        </Button>
      </CardContent>
    </Card>
  );
}
