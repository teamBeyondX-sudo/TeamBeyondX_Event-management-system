import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Calendar,
  Users,
  LogOut,
  ChevronLeft,
  Building
} from "lucide-react";

interface AdminLayoutProps {
  children: ReactNode;
  title: string;
}

export default function AdminLayout({ children, title }: AdminLayoutProps) {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const navItems = [
    {
      name: "Dashboard",
      path: "/admin",
      icon: <LayoutDashboard className="h-5 w-5 mr-2" />,
    },
    {
      name: "Events",
      path: "/admin/events",
      icon: <Calendar className="h-5 w-5 mr-2" />,
    },
    {
      name: "Clubs",
      path: "/admin/clubs",
      icon: <Building className="h-5 w-5 mr-2" />,
    },
    {
      name: "Participants",
      path: "/admin/participants",
      icon: <Users className="h-5 w-5 mr-2" />,
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      {/* Admin Header */}
      <header className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 shadow-sm py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center">
            <Link href="/">
              <Button variant="outline" size="sm" className="mr-4">
                <ChevronLeft className="h-4 w-4 mr-1" />
                Back to Site
              </Button>
            </Link>
            <h1 className="text-2xl font-poppins font-bold">{title}</h1>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="text-red-600 dark:text-red-400"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      <div className="flex flex-grow">
        {/* Sidebar */}
        <aside className="w-64 bg-white dark:bg-gray-800 border-r dark:border-gray-700 shadow-sm hidden md:block">
          <div className="p-4">
            <div className="text-xl font-poppins font-bold text-primary mb-6">Admin Panel</div>
            <nav className="space-y-1">
              {navItems.map((item) => (
                <Link key={item.path} href={item.path}>
                  <a
                    className={`flex items-center px-4 py-3 rounded-lg transition-colors ${
                      location === item.path
                        ? "bg-primary text-white"
                        : "hover:bg-gray-100 dark:hover:bg-gray-700"
                    }`}
                  >
                    {item.icon}
                    {item.name}
                  </a>
                </Link>
              ))}
            </nav>
          </div>
        </aside>

        {/* Mobile Navigation */}
        <div className="md:hidden bg-white dark:bg-gray-800 border-b dark:border-gray-700 shadow-sm p-4 flex justify-center">
          <div className="flex space-x-4">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <a
                  className={`p-2 rounded-lg transition-colors ${
                    location === item.path
                      ? "bg-primary text-white"
                      : "bg-gray-100 dark:bg-gray-700"
                  }`}
                >
                  {item.icon}
                </a>
              </Link>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <main className="flex-1 p-6 overflow-auto">
          <div className="container mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
