import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { format } from "date-fns";
import Layout from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Calendar, Users, InfoIcon } from "lucide-react";
import { Club } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type ExtendedClub = Club & {
  role: string;
  joinDate: string;
  events?: {
    id: number;
    title: string;
    date: string;
    image: string;
    location: string;
    price: number;
  }[];
};

export default function MyClubs() {
  const { toast } = useToast();
  
  // Fetch user club memberships
  const { data: clubs, isLoading, error } = useQuery<ExtendedClub[]>({
    queryKey: ["/api/my-clubs"],
  });
  
  // Leave club mutation
  const leaveClubMutation = useMutation({
    mutationFn: async (clubId: number) => {
      const res = await apiRequest("DELETE", `/api/clubs/${clubId}/leave`);
      if (!res.ok) {
        throw new Error("Failed to leave club");
      }
      return clubId;
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "You have left the club",
      });
      // Invalidate queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/my-clubs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/clubs"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center items-center py-20">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <h1 className="font-poppins font-bold text-3xl mb-8">My Clubs</h1>
          <div className="text-center py-16 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <InfoIcon className="mx-auto h-12 w-12 text-red-500 mb-4" />
            <h3 className="text-xl font-medium mb-4">Error Loading Clubs</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-8">
              There was a problem loading your club memberships.
            </p>
            <Button variant="outline" onClick={() => window.location.reload()}>
              Try Again
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  if (!clubs || clubs.length === 0) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <h1 className="font-poppins font-bold text-3xl mb-8">My Clubs</h1>
          <div className="text-center py-16 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <h3 className="text-xl font-medium mb-4">No Club Memberships Found</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-8">
              You are not a member of any clubs yet.
            </p>
            <Button asChild>
              <Link href="/clubs">
                Explore Clubs
              </Link>
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12">
        <h1 className="font-poppins font-bold text-3xl mb-8">My Clubs</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {clubs.map((club) => (
            <Card key={club.id} className="overflow-hidden">
              <div className="p-6 text-white" style={{ backgroundColor: club.backgroundColor }}>
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center">
                    <div className="h-12 w-12 rounded-full bg-white/20 flex items-center justify-center">
                      <i className={`${club.icon} text-xl`}></i>
                    </div>
                    <h3 className="ml-3 font-poppins font-semibold text-xl">{club.name}</h3>
                  </div>
                  <Badge className="bg-white/20 hover:bg-white/30">
                    {club.role}
                  </Badge>
                </div>
                <div className="text-white/80 text-sm">
                  <div className="flex items-center mb-2">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>Joined {format(new Date(club.joinDate), "MMM d, yyyy")}</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-2" />
                    <span>{club.memberCount} members</span>
                  </div>
                </div>
              </div>
              <CardContent className="p-6">
                <p className="text-gray-600 dark:text-gray-300 mb-6 line-clamp-3">
                  {club.description}
                </p>
                
                <div className="flex justify-between items-center space-x-3">
                  <Link href={`/clubs/${club.id}`}>
                    <Button variant="outline" className="flex-1">
                      Club Details
                    </Button>
                  </Link>
                  <Link href={`/clubs/${club.id}/members`}>
                    <Button variant="outline" className="flex-1">
                      View Members
                    </Button>
                  </Link>
                  <Button
                    variant="destructive"
                    className="flex-none"
                    disabled={leaveClubMutation.isPending}
                    onClick={() => {
                      if (confirm(`Are you sure you want to leave ${club.name}?`)) {
                        leaveClubMutation.mutate(club.id);
                      }
                    }}
                  >
                    {leaveClubMutation.isPending ? (
                      <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Leaving...</>
                    ) : (
                      "Leave"
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}