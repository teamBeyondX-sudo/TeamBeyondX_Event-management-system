import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Link } from "wouter";
import Layout from "@/components/layout";
import HeroSection from "@/components/hero-section";
import EventCard from "@/components/event-card";
import ClubCard from "@/components/club-card";
import { Button } from "@/components/ui/button";
import { Event, Club } from "@shared/schema";
import { Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function HomePage() {
  const [showAllEvents, setShowAllEvents] = useState(false);
  const { user } = useAuth();

  // Fetch events
  const { data: events, isLoading: eventsLoading } = useQuery<(Event & {
    club?: { name: string; icon: string; backgroundColor: string };
    category?: { name: string; color: string };
  })[]>({
    queryKey: ["/api/events"],
  });

  // Fetch clubs
  const { data: clubs, isLoading: clubsLoading } = useQuery<Club[]>({
    queryKey: ["/api/clubs"],
  });

  // Show only the first 6 events initially
  const displayedEvents = showAllEvents ? events : events?.slice(0, 6);

  return (
    <Layout>
      <HeroSection />

      {/* Events Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="font-poppins font-bold text-3xl">Upcoming Events</h2>
            <Link href="/events">
              <a className="text-primary hover:underline font-medium flex items-center">
                View All
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 ml-1"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                >
                  <path
                    fillRule="evenodd"
                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
              </a>
            </Link>
          </div>

          {eventsLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : events && events.length > 0 ? (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {displayedEvents?.map((event) => (
                  <Link key={event.id} href={`/events/${event.id}`}>
                    <a className="block">
                      <EventCard event={event} />
                    </a>
                  </Link>
                ))}
              </div>

              {events.length > 6 && !showAllEvents && (
                <div className="mt-12 text-center">
                  <Button
                    variant="outline"
                    className="border-primary text-primary px-6 py-3"
                    onClick={() => setShowAllEvents(true)}
                  >
                    Load More Events
                  </Button>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <h3 className="text-lg font-medium mb-2">No events found</h3>
              <p className="text-gray-500 dark:text-gray-400">
                There are no upcoming events at the moment.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Clubs Section */}
      <section className="py-16 bg-gray-50 dark:bg-gray-900">
        <div className="container mx-auto px-4">
          <h2 className="font-poppins font-bold text-3xl mb-8">Featured Clubs</h2>

          {clubsLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : clubs && clubs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {clubs.slice(0, 4).map((club) => (
                <Link key={club.id} href={`/clubs`}>
                  <a className="block">
                    <ClubCard club={club} />
                  </a>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-gray-100 dark:bg-gray-800 rounded-lg">
              <h3 className="text-lg font-medium mb-2">No clubs found</h3>
              <p className="text-gray-500 dark:text-gray-400">
                There are no clubs registered at the moment.
              </p>
            </div>
          )}

          <div className="mt-12 text-center">
            <Link href="/clubs">
              <a className="inline-flex items-center text-primary font-poppins font-medium hover:underline bg-blue-50 dark:bg-blue-900/30 px-4 py-2 rounded-full">
                View All Clubs <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 ml-2"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                >
                  <path
                    fillRule="evenodd"
                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Call to Action - Only for admins */}
      {user?.role === "admin" && (
        <section className="py-16 bg-primary">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center text-white">
              <h2 className="font-poppins font-bold text-3xl mb-4">Admin Actions</h2>
              <p className="text-lg mb-8 text-white/90">
                As an administrator, you can create new clubs and organize events on campus.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center">
                <Link href="/create-club">
                  <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
                    Start a Club
                  </Button>
                </Link>
                <Link href="/create-event">
                  <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white/10">
                    Organize an Event
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      )}
    </Layout>
  );
}
