import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { format } from "date-fns";
import Layout from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, Loader2, ChevronLeft, Users, Info } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Club, Event } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

type ExtendedClub = Club & {
  events?: (Event & {
    statusText: string;
    isRegistrationOpen: boolean;
  })[];
};

export default function ClubDetails() {
  const [match, params] = useRoute<{ id: string }>("/clubs/:id");
  const clubId = params?.id ? parseInt(params.id, 10) : 0;
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch club details
  const { data: club, isLoading, error } = useQuery<ExtendedClub>({
    queryKey: [`/api/clubs/${clubId}`],
    enabled: !!clubId,
  });

  // Join club mutation
  const joinClubMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/clubs/${clubId}/join`, { role: "member" });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to join club");
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Club joined successfully!",
        description: "You are now a member of this club.",
      });
      // Invalidate both clubs and my-clubs queries
      queryClient.invalidateQueries({ queryKey: ["/api/clubs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/my-clubs"] });
      queryClient.invalidateQueries({ queryKey: [`/api/clubs/${clubId}`] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to join club",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleJoinClub = () => {
    joinClubMutation.mutate();
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center items-center py-20">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (error || !club) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <Button asChild variant="outline" className="mb-6">
            <Link href="/clubs">
              <a className="flex items-center">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Clubs
              </a>
            </Link>
          </Button>
          
          <div className="text-center py-16 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <Info className="mx-auto h-12 w-12 text-red-500 mb-4" />
            <h3 className="text-xl font-medium mb-4">Error Loading Club</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-8">
              There was a problem loading the club details.
            </p>
            <Button variant="outline" onClick={() => window.location.reload()}>
              Try Again
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12">
        <Button asChild variant="outline" className="mb-6">
          <Link href="/clubs" className="flex items-center">
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back to Clubs
          </Link>
        </Button>

        {/* Club Header */}
        <div 
          className="p-8 rounded-lg text-white mb-8"
          style={{ backgroundColor: club.backgroundColor }}
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex items-center">
              <div className="h-16 w-16 rounded-full bg-white/20 flex items-center justify-center">
                <i className={`${club.icon} text-2xl`}></i>
              </div>
              <div className="ml-4">
                <h1 className="font-poppins font-bold text-3xl mb-1">{club.name}</h1>
                <div className="flex items-center text-white/80">
                  <Users className="h-4 w-4 mr-2" />
                  <span>{club.memberCount} members</span>
                </div>
              </div>
            </div>
            
            <div className="flex gap-3">
              <Button 
                onClick={handleJoinClub}
                disabled={joinClubMutation.isPending}
                className="bg-white text-black hover:bg-white/90"
              >
                {joinClubMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : null}
                Join Club
              </Button>
              <Link href={`/clubs/${clubId}/members`}>
                <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/10">
                  View Members
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Club Description */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 mb-8 shadow-sm">
          <h2 className="font-poppins font-semibold text-xl mb-4">About this Club</h2>
          <p className="text-gray-600 dark:text-gray-300 whitespace-pre-line">
            {club.description}
          </p>
        </div>

        {/* Club Events */}
        <div>
          <h2 className="font-poppins font-semibold text-2xl mb-6">Club Events</h2>
          
          {!club.events || club.events.length === 0 ? (
            <div className="text-center py-16 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <h3 className="text-xl font-medium mb-4">No Events Found</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-6">
                This club doesn't have any events yet.
              </p>
            </div>
          ) : (
            <Tabs defaultValue="all">
              <TabsList className="mb-6">
                <TabsTrigger value="all">
                  All Events ({club.events.length})
                </TabsTrigger>
                <TabsTrigger value="upcoming">
                  Upcoming Events ({club.events.filter(e => e.statusText === "Upcoming").length})
                </TabsTrigger>
                <TabsTrigger value="past">
                  Past Events ({club.events.filter(e => e.statusText === "Closed").length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="all">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {club.events.map((event) => (
                    <EventCard key={event.id} event={event} />
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="upcoming">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {club.events
                    .filter(event => event.statusText === "Upcoming")
                    .map((event) => (
                      <EventCard key={event.id} event={event} />
                    ))}
                </div>
                {club.events.filter(e => e.statusText === "Upcoming").length === 0 && (
                  <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <h3 className="text-lg font-medium mb-2">No upcoming events</h3>
                    <p className="text-gray-500 dark:text-gray-400">
                      This club doesn't have any upcoming events.
                    </p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="past">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {club.events
                    .filter(event => event.statusText === "Closed")
                    .map((event) => (
                      <EventCard key={event.id} event={event} />
                    ))}
                </div>
                {club.events.filter(e => e.statusText === "Closed").length === 0 && (
                  <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <h3 className="text-lg font-medium mb-2">No past events</h3>
                    <p className="text-gray-500 dark:text-gray-400">
                      This club doesn't have any past events.
                    </p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          )}
        </div>
      </div>
    </Layout>
  );
}

function EventCard({ event }: { event: Event & { statusText: string; isRegistrationOpen: boolean } }) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="relative h-48">
        <img
          src={event.image}
          alt={event.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-4 right-4">
          <Badge
            className={
              event.statusText === "Upcoming"
                ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100"
                : "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
            }
          >
            {event.statusText}
          </Badge>
        </div>
      </div>
      <CardContent className="p-6">
        <h3 className="font-poppins font-semibold text-xl mb-3 line-clamp-1">{event.title}</h3>
        <div className="space-y-2 text-sm text-gray-500 dark:text-gray-400 mb-4">
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-2" />
            <span>{format(new Date(event.date), "MMM d, yyyy")} • {event.time}</span>
          </div>
          <div className="flex items-center">
            <MapPin className="h-4 w-4 mr-2" />
            <span className="line-clamp-1">{event.location}</span>
          </div>
          <div className="flex items-center font-medium">
            <span>₹{event.price}</span>
            {event.price === 0 && <span className="ml-2 text-green-600 dark:text-green-400">(Free)</span>}
          </div>
        </div>
        <Link href={`/events/${event.id}`}>
          <Button className="w-full">View Details</Button>
        </Link>
      </CardContent>
    </Card>
  );
}