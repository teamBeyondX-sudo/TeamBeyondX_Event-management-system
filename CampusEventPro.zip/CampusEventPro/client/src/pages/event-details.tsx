import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { format } from "date-fns";
import Layout from "@/components/layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, CalendarIcon, Clock, MapPin, Tag, Users } from "lucide-react";
import { Event } from "@shared/schema";
import RegistrationModal from "@/components/registration-modal";
import PaymentModal from "@/components/payment-modal";

export default function EventDetails() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [showRegistrationModal, setShowRegistrationModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [registrationId, setRegistrationId] = useState<number | null>(null);

  // Fetch event details
  const { data: event, isLoading } = useQuery<Event & {
    club?: { 
      name: string;
      icon: string;
      backgroundColor: string;
      description: string;
    };
    category?: { name: string; color: string };
  }>({
    queryKey: [`/api/events/${id}`],
  });

  // Check if user is already registered
  const { data: registrations, isLoading: registrationsLoading } = useQuery<any[]>({
    queryKey: ["/api/registrations"],
    enabled: !!user, // Only fetch if user is logged in
  });

  const userRegistration = registrations?.find(reg => reg.eventId === Number(id));
  const isRegistered = !!userRegistration;
  const isPaymentPending = userRegistration?.paymentStatus === "pending";

  const handleRegisterClick = () => {
    if (!user) {
      window.location.href = "/auth"; // Redirect to auth page
      return;
    }
    setShowRegistrationModal(true);
  };

  const handleRegistrationSuccess = (regId: number) => {
    setRegistrationId(regId);
    if (event && event.price > 0) {
      setShowPaymentModal(true);
    }
  };

  const handlePaymentSuccess = () => {
    setShowPaymentModal(false);
  };

  const calculateTotal = (price: number) => {
    return price + (price * 0.18);
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center items-center py-20">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (!event) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-20 text-center">
          <h2 className="text-2xl font-bold mb-4">Event Not Found</h2>
          <p className="text-gray-500 mb-8">The event you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link href="/events">Back to Events</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="relative">
        <div className="h-64 md:h-80 w-full bg-gray-200 dark:bg-gray-700">
          <img 
            src={event.image} 
            alt={event.title} 
            className="w-full h-full object-cover" 
          />
        </div>
        
        <div className="container mx-auto px-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg -mt-20 relative z-10 p-6 md:p-8 mb-10">
            <div className="flex items-center flex-wrap gap-2 mb-4">
              {event.category && (
                <Badge
                  className="text-white"
                  style={{ backgroundColor: event.category.color }}
                >
                  {event.category.name}
                </Badge>
              )}
              <Badge className={`${event.registrationsCount >= event.capacity 
                ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100" 
                : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100"}`}
              >
                {event.registrationsCount >= event.capacity 
                  ? "Full" 
                  : "Registrations Open"}
              </Badge>
              <Badge variant="outline">
                <Users className="h-3 w-3 mr-1" /> {event.registrationsCount}/{event.capacity} registered
              </Badge>
            </div>
            
            <h1 className="font-poppins font-bold text-2xl md:text-3xl mb-2">
              {event.title}
            </h1>
            
            <div className="flex flex-wrap items-center text-gray-500 dark:text-gray-400 mb-6 gap-y-2">
              <div className="flex items-center mr-6">
                <CalendarIcon className="h-4 w-4 mr-2" />
                <span>{format(new Date(event.date), "MMMM d, yyyy")}</span>
              </div>
              <div className="flex items-center mr-6">
                <Clock className="h-4 w-4 mr-2" />
                <span>{event.time}</span>
              </div>
              <div className="flex items-center mr-6">
                <MapPin className="h-4 w-4 mr-2" />
                <span>{event.location}</span>
              </div>
              <div className="flex items-center">
                <Tag className="h-4 w-4 mr-2" />
                <span>{event.price === 0 ? "Free" : `₹${event.price} per participant`}</span>
              </div>
            </div>
            
            <div className="mb-8">
              <h2 className="font-poppins font-semibold text-xl mb-3">About Event</h2>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                {event.description}
              </p>
              {event.highlights && event.highlights.length > 0 && (
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 mt-4">
                  <h3 className="font-poppins font-semibold mb-2">Event Highlights</h3>
                  <ul className="list-disc list-inside text-gray-600 dark:text-gray-300 space-y-1">
                    {event.highlights.map((highlight, index) => (
                      <li key={index}>{highlight}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            
            {event.club && (
              <div className="mb-8">
                <h2 className="font-poppins font-semibold text-xl mb-3">Organizer</h2>
                <div className="flex items-center">
                  <div 
                    className="h-12 w-12 rounded-full flex items-center justify-center text-white"
                    style={{ backgroundColor: event.club.backgroundColor }}
                  >
                    <i className={`${event.club.icon} text-2xl`}></i>
                  </div>
                  <div className="ml-3">
                    <h3 className="font-medium">{event.club.name}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {event.club.description}
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            <Separator className="my-6" />
            
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div className="mb-4 md:mb-0">
                <h2 className="font-poppins font-semibold text-xl">Registration</h2>
                {isRegistered ? (
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {isPaymentPending 
                      ? "Complete your payment to confirm registration" 
                      : "You're registered for this event"}
                  </p>
                ) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Registration closes on {format(new Date(event.date), "MMMM d, yyyy")}
                  </p>
                )}
              </div>
              
              <div className="flex items-center space-x-4">
                {event.price > 0 && (
                  <div className="text-2xl font-poppins font-bold text-primary">₹{event.price}</div>
                )}
                
                {isRegistered ? (
                  isPaymentPending ? (
                    <Button 
                      onClick={() => {
                        setRegistrationId(userRegistration.id);
                        setShowPaymentModal(true);
                      }}
                    >
                      Complete Payment
                    </Button>
                  ) : (
                    <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100 text-sm py-2 px-4">
                      Registration Confirmed
                    </Badge>
                  )
                ) : (
                  <Button 
                    className="w-full md:w-auto" 
                    onClick={handleRegisterClick}
                    disabled={event.registrationsCount >= event.capacity || event.status !== "active"}
                  >
                    {event.registrationsCount >= event.capacity
                      ? "Event Full"
                      : "Register Now"}
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Registration Modal */}
      {event && (
        <RegistrationModal 
          event={event}
          open={showRegistrationModal}
          onOpenChange={setShowRegistrationModal}
          onSuccess={handleRegistrationSuccess}
        />
      )}

      {/* Payment Modal */}
      {registrationId && event && (
        <PaymentModal 
          open={showPaymentModal}
          onOpenChange={setShowPaymentModal}
          registrationId={registrationId}
          amount={calculateTotal(event.price)}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </Layout>
  );
}
