import { useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import Layout from "@/components/layout";
import { Button } from "@/components/ui/button";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";

// Schema for creating a club
const createClubSchema = z.object({
  name: z.string().min(3, "Club name must be at least 3 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  icon: z.string().min(1, "Icon is required"),
  backgroundColor: z.string().min(1, "Background color is required")
});

type CreateClubFormValues = z.infer<typeof createClubSchema>;

// Predefined icon options
const iconOptions = [
  "🎓", "📚", "🎭", "🎨", "🎬", "📷", "🎤", "🎵", "🎮", 
  "⚽", "🏀", "🏈", "⚾", "🎾", "🏐", "🏉", "🎱", "🎯", 
  "♟️", "🎲", "🧩", "🧠", "💻", "🤖", "🔬", "🧪", "📊", 
  "💡", "🌱", "🍲", "🥗", "☕"
];

// Predefined color options with hex codes
const colorOptions = [
  { name: "Blue", hex: "#2563eb" },
  { name: "Indigo", hex: "#4f46e5" },
  { name: "Purple", hex: "#7c3aed" },
  { name: "Pink", hex: "#db2777" },
  { name: "Red", hex: "#dc2626" },
  { name: "Orange", hex: "#ea580c" },
  { name: "Yellow", hex: "#ca8a04" },
  { name: "Green", hex: "#16a34a" },
  { name: "Teal", hex: "#0d9488" },
  { name: "Cyan", hex: "#0891b2" },
  { name: "Slate", hex: "#475569" },
  { name: "Gray", hex: "#71717a" }
];

export default function CreateClubPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  // Redirect early check is handled by the ProtectedRoute component

  const [selectedIcon, setSelectedIcon] = useState<string>("🎓");
  const [selectedColor, setSelectedColor] = useState<string>("#2563eb");

  // Create form
  const form = useForm<CreateClubFormValues>({
    resolver: zodResolver(createClubSchema),
    defaultValues: {
      name: "",
      description: "",
      icon: "🎓",
      backgroundColor: "#2563eb"
    }
  });

  // Handle icon selection
  const handleIconSelect = (icon: string) => {
    setSelectedIcon(icon);
    form.setValue("icon", icon);
  };

  // Handle color selection
  const handleColorSelect = (hex: string) => {
    setSelectedColor(hex);
    form.setValue("backgroundColor", hex);
  };

  // Create club mutation
  const createClubMutation = useMutation({
    mutationFn: async (data: CreateClubFormValues) => {
      const response = await apiRequest("POST", "/api/clubs", data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Club created successfully!",
        description: "Your club has been created. You can now start organizing events.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/clubs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/my-clubs"] });
      navigate("/my-clubs");
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create club",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Submit handler
  function onSubmit(data: CreateClubFormValues) {
    createClubMutation.mutate({
      ...data,
      icon: selectedIcon,
      backgroundColor: selectedColor
    });
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-poppins font-bold mb-2">Start a New Club</h1>
          <p className="text-gray-600 mb-8">
            Create your own club and bring together people with similar interests.
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Club Details</CardTitle>
                <CardDescription>
                  Fill out the information about your new club
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Club Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Photography Club" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell us about your club's mission, activities, and benefits of joining." 
                              rows={4}
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="space-y-3">
                      <Label htmlFor="icon-selection">Club Icon</Label>
                      <div className="grid grid-cols-8 gap-2 p-2 border rounded-md">
                        {iconOptions.map((icon) => (
                          <button
                            key={icon}
                            type="button"
                            onClick={() => handleIconSelect(icon)}
                            className={`text-2xl p-2 rounded-md border ${
                              selectedIcon === icon
                                ? "border-primary bg-primary/10"
                                : "border-gray-200 hover:border-gray-300"
                            }`}
                          >
                            {icon}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-3">
                      <Label htmlFor="color-selection">Club Color</Label>
                      <div className="grid grid-cols-6 gap-2">
                        {colorOptions.map((color) => (
                          <button
                            key={color.hex}
                            type="button"
                            title={color.name}
                            onClick={() => handleColorSelect(color.hex)}
                            className={`w-10 h-10 rounded-full border-2 ${
                              selectedColor === color.hex
                                ? "border-black scale-110"
                                : "border-transparent"
                            }`}
                            style={{ backgroundColor: color.hex }}
                          />
                        ))}
                      </div>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={createClubMutation.isPending}
                    >
                      {createClubMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Creating...
                        </>
                      ) : "Create Club"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Preview</CardTitle>
                <CardDescription>How your club will appear</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center">
                  <div 
                    className="w-20 h-20 rounded-full flex items-center justify-center text-3xl mb-4"
                    style={{ backgroundColor: selectedColor }}
                  >
                    <span className="text-white">{selectedIcon}</span>
                  </div>
                  
                  <h3 className="text-xl font-semibold text-center mb-2">
                    {form.watch("name") || "Club Name"}
                  </h3>
                  
                  <p className="text-sm text-gray-600 text-center line-clamp-4">
                    {form.watch("description") || "Club description will appear here..."}
                  </p>
                  
                  <div className="mt-4 text-sm text-gray-500">
                    <span className="font-semibold">Members:</span> 1 (You)
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}