import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { format } from "date-fns";
import Layout from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Loader2, Calendar, MapPin, Tag } from "lucide-react";
import PaymentModal from "@/components/payment-modal";
import { Registration } from "@shared/schema";

type ExtendedRegistration = Registration & {
  event: {
    id: number;
    title: string;
    date: string;
    time: string;
    location: string;
    price: number;
    image: string;
    club: {
      name: string;
      backgroundColor: string;
      icon: string;
    };
    category: {
      name: string;
      color: string;
    };
  };
};

export default function MyRegistrations() {
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedRegistration, setSelectedRegistration] = useState<ExtendedRegistration | null>(null);

  // Fetch user registrations
  const { data: registrations, isLoading } = useQuery<ExtendedRegistration[]>({
    queryKey: ["/api/registrations"],
  });

  const upcomingRegistrations = registrations?.filter(
    (reg) => new Date(reg.event.date) >= new Date()
  );

  const pastRegistrations = registrations?.filter(
    (reg) => new Date(reg.event.date) < new Date()
  );

  const handleCompletePayment = (registration: ExtendedRegistration) => {
    setSelectedRegistration(registration);
    setShowPaymentModal(true);
  };

  const handlePaymentSuccess = () => {
    setShowPaymentModal(false);
  };

  const calculateTotal = (price: number) => {
    return price + (price * 0.18);
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center items-center py-20">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (!registrations || registrations.length === 0) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <h1 className="font-poppins font-bold text-3xl mb-8">My Registrations</h1>
          <div className="text-center py-16 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <h3 className="text-xl font-medium mb-4">No Registrations Found</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-8">
              You haven't registered for any events yet.
            </p>
            <Button asChild>
              <Link href="/events">
                <a>Explore Events</a>
              </Link>
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12">
        <h1 className="font-poppins font-bold text-3xl mb-8">My Registrations</h1>

        <Tabs defaultValue="upcoming">
          <TabsList className="mb-6">
            <TabsTrigger value="upcoming">
              Upcoming Events ({upcomingRegistrations?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="past">
              Past Events ({pastRegistrations?.length || 0})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {upcomingRegistrations?.map((registration) => (
                <Card key={registration.id} className="overflow-hidden">
                  <div className="relative h-40">
                    <img
                      src={registration.event.image}
                      alt={registration.event.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-4 left-4">
                      <Badge
                        className="text-white"
                        style={{ backgroundColor: registration.event.category.color }}
                      >
                        {registration.event.category.name}
                      </Badge>
                    </div>
                    <div className="absolute top-4 right-4">
                      <Badge
                        className={
                          registration.paymentStatus === "completed"
                            ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100"
                            : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100"
                        }
                      >
                        {registration.paymentStatus === "completed"
                          ? "Confirmed"
                          : "Payment Pending"}
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <h3 className="font-poppins font-semibold text-xl mb-3">
                      {registration.event.title}
                    </h3>
                    <div className="space-y-2 text-sm text-gray-500 dark:text-gray-400 mb-4">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2" />
                        <span>
                          {format(new Date(registration.event.date), "MMM d, yyyy")} • {registration.event.time}
                        </span>
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-2" />
                        <span>{registration.event.location}</span>
                      </div>
                      {registration.teamName && (
                        <div className="flex items-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-4 w-4 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                            />
                          </svg>
                          <span>Team: {registration.teamName} ({registration.teamSize} members)</span>
                        </div>
                      )}
                      <div className="flex items-center">
                        <Tag className="h-4 w-4 mr-2" />
                        <span>₹{registration.paymentAmount}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div
                          className="h-8 w-8 rounded-full flex items-center justify-center text-white"
                          style={{ backgroundColor: registration.event.club.backgroundColor }}
                        >
                          <i className={registration.event.club.icon}></i>
                        </div>
                        <span className="ml-2 text-sm font-medium">
                          {registration.event.club.name}
                        </span>
                      </div>

                      {registration.paymentStatus === "pending" && (
                        <Button onClick={() => handleCompletePayment(registration)}>
                          Complete Payment
                        </Button>
                      )}
                      {registration.paymentStatus === "completed" && (
                        <Link href={`/events/${registration.event.id}`}>
                          <Button variant="outline">View Event</Button>
                        </Link>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {upcomingRegistrations?.length === 0 && (
              <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <h3 className="text-lg font-medium mb-2">No upcoming events</h3>
                <p className="text-gray-500 dark:text-gray-400 mb-4">
                  You don't have any upcoming event registrations.
                </p>
                <Button asChild>
                  <Link href="/events">
                    <a>Browse Events</a>
                  </Link>
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="past">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {pastRegistrations?.map((registration) => (
                <Card key={registration.id} className="overflow-hidden">
                  <div className="relative h-40">
                    <img
                      src={registration.event.image}
                      alt={registration.event.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-4 left-4">
                      <Badge
                        className="text-white"
                        style={{ backgroundColor: registration.event.category.color }}
                      >
                        {registration.event.category.name}
                      </Badge>
                    </div>
                    <div className="absolute top-4 right-4">
                      <Badge variant="outline" className="bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200">
                        Completed
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <h3 className="font-poppins font-semibold text-xl mb-3">
                      {registration.event.title}
                    </h3>
                    <div className="space-y-2 text-sm text-gray-500 dark:text-gray-400 mb-4">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2" />
                        <span>
                          {format(new Date(registration.event.date), "MMM d, yyyy")} • {registration.event.time}
                        </span>
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-2" />
                        <span>{registration.event.location}</span>
                      </div>
                      {registration.teamName && (
                        <div className="flex items-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-4 w-4 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                            />
                          </svg>
                          <span>Team: {registration.teamName} ({registration.teamSize} members)</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div
                          className="h-8 w-8 rounded-full flex items-center justify-center text-white"
                          style={{ backgroundColor: registration.event.club.backgroundColor }}
                        >
                          <i className={registration.event.club.icon}></i>
                        </div>
                        <span className="ml-2 text-sm font-medium">
                          {registration.event.club.name}
                        </span>
                      </div>

                      <Link href={`/events/${registration.event.id}`}>
                        <Button variant="outline">View Event</Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {pastRegistrations?.length === 0 && (
              <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <h3 className="text-lg font-medium mb-2">No past events</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  You don't have any past event registrations.
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Payment Modal */}
        {selectedRegistration && (
          <PaymentModal
            open={showPaymentModal}
            onOpenChange={setShowPaymentModal}
            registrationId={selectedRegistration.id}
            amount={calculateTotal(selectedRegistration.paymentAmount)}
            onSuccess={handlePaymentSuccess}
          />
        )}
      </div>
    </Layout>
  );
}
