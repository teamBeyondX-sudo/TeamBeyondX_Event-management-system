import { useMutation, useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import Layout from "@/components/layout";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

// Schema for creating an event
const createEventSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  date: z.date({
    required_error: "Event date is required",
  }),
  time: z.string().min(1, "Time is required"),
  location: z.string().min(3, "Location must be at least 3 characters"),
  price: z.coerce.number().min(0, "Price must be 0 or greater"),
  capacity: z.coerce.number().min(1, "Capacity must be at least 1"),
  image: z.string().min(1, "Image URL is required"),
  status: z.string().min(1, "Status is required"),
  clubId: z.coerce.number().min(1, "Club is required"),
  categoryId: z.coerce.number().min(1, "Category is required"),
  highlights: z.array(z.string()).optional(),
});

type CreateEventFormValues = z.infer<typeof createEventSchema>;

// Predefined image URLs related to college events
const eventImageOptions = [
  "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=1000&q=80", // Tech meetup
  "https://images.unsplash.com/photo-1515168833906-d2a3b82b302a?auto=format&fit=crop&w=1000&q=80", // Music event
  "https://images.unsplash.com/photo-1504805572947-34fad45aed93?auto=format&fit=crop&w=1000&q=80", // Sports event
  "https://images.unsplash.com/photo-1528605248644-14dd04022da1?auto=format&fit=crop&w=1000&q=80", // Arts event
  "https://images.unsplash.com/photo-1531058020387-3be344556be6?auto=format&fit=crop&w=1000&q=80", // Debate event
  "https://images.unsplash.com/photo-1491336477066-31156b5e4f35?auto=format&fit=crop&w=1000&q=80", // Cultural event
  "https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?auto=format&fit=crop&w=1000&q=80", // Science fair
  "https://images.unsplash.com/photo-1560523160-754a9e25c68f?auto=format&fit=crop&w=1000&q=80", // Hackathon
  "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?auto=format&fit=crop&w=1000&q=80", // Workshop
];

// Function to fetch query data
function getQueryFn({ on401 }: { on401: "throw" | "returnNull" }) {
  return async ({ queryKey }: { queryKey: (string | number)[] }) => {
    const endpoint = queryKey[0] as string;
    const response = await fetch(endpoint);
    
    if (response.status === 401) {
      if (on401 === "throw") {
        throw new Error("Unauthorized");
      } else {
        return null;
      }
    }
    
    if (!response.ok) {
      throw new Error(`Network response was not ok: ${response.statusText}`);
    }
    
    return response.json();
  };
}

export default function CreateEventPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  // Fetch clubs where user is a leader or admin
  const { data: myClubs, isLoading: isLoadingClubs } = useQuery({
    queryKey: ["/api/my-clubs"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Fetch categories
  const { data: categories = [], isLoading: isLoadingCategories } = useQuery({
    queryKey: ["/api/categories"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });
  
  // Fetch all clubs for admins
  const { data: allClubs = [] } = useQuery({
    queryKey: ["/api/clubs"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: user?.role === "admin", // Only fetch if user is admin
  });
  
  // Use all clubs for club selection
  const clubOptions = allClubs || [];

  // Create form
  const form = useForm<CreateEventFormValues>({
    resolver: zodResolver(createEventSchema),
    defaultValues: {
      title: "",
      description: "",
      date: new Date(),
      time: "18:00",
      location: "",
      price: 0,
      capacity: 50,
      image: eventImageOptions[0],
      status: "upcoming",
      clubId: clubOptions && clubOptions.length > 0 ? clubOptions[0].id : 1,
      categoryId: categories && categories.length > 0 ? categories[0].id : 1,
      highlights: [],
    },
  });

  // Create event mutation
  const createEventMutation = useMutation({
    mutationFn: async (data: CreateEventFormValues) => {
      // Ensure numeric fields are parsed as numbers
      const formattedData = {
        ...data,
        date: data.date.toISOString(),
        clubId: parseInt(String(data.clubId), 10),
        categoryId: parseInt(String(data.categoryId), 10),
        price: parseInt(String(data.price), 10),
        capacity: parseInt(String(data.capacity), 10),
        highlights: data.highlights || [],
      };
      
      console.log("Sending to API:", formattedData);
      
      const response = await apiRequest("POST", "/api/events", formattedData);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Event created successfully!",
        description: "Your event has been published.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      navigate("/events");
    },
    onError: (error: Error) => {
      console.error("Error creating event:", error);
      toast({
        title: "Failed to create event",
        description: error.message || "There was a problem with your request. Check the form and try again.",
        variant: "destructive",
      });
    },
  });

  // Submit handler
  function onSubmit(data: CreateEventFormValues) {
    // Validate that we have values for required fields
    if (!data.clubId || data.clubId < 1) {
      toast({
        title: "Validation Error",
        description: "Please select a club for this event",
        variant: "destructive",
      });
      return;
    }
    
    if (!data.categoryId || data.categoryId < 1) {
      toast({
        title: "Validation Error",
        description: "Please select a category for this event",
        variant: "destructive",
      });
      return;
    }
    
    // Ensure date is properly formatted
    try {
      // Log the data we're submitting for debugging
      console.log("Submitting event data:", {
        ...data,
        date: data.date.toISOString(),
        clubId: data.clubId,
        categoryId: data.categoryId
      });
      
      createEventMutation.mutate(data);
    } catch (error) {
      console.error("Error submitting event:", error);
      toast({
        title: "Error",
        description: "There was a problem creating your event. Please try again.",
        variant: "destructive",
      });
    }
  }

  if (isLoadingClubs || isLoadingCategories) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-16 flex justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  // Check if user is an admin - only admins can create events now
  if (user?.role !== "admin") {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Administrator Access Required</CardTitle>
              <CardDescription>
                Only administrators can create and organize events
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-4">
                <div className="flex">
                  <div className="flex-shrink-0 text-yellow-400">
                    <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-yellow-700">
                      This is a restricted feature. Please contact an administrator if you need to organize an event.
                    </p>
                  </div>
                </div>
              </div>
              <p>To create an event, you need administrator privileges. Some options:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Contact an administrator to request event creation</li>
                <li>Login with an administrator account if you have one</li>
              </ul>
              <Button onClick={() => navigate("/")} className="mt-4">
                Return to Home
              </Button>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-poppins font-bold mb-2">Organize a New Event</h1>
          <p className="text-gray-600 mb-8">
            Create your event and invite students to participate.
          </p>

          <Card>
            <CardHeader>
              <CardTitle>Event Details</CardTitle>
              <CardDescription>
                Fill out the information about your new event
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Event Title</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Annual Hackathon" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Main Auditorium" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Describe your event, its purpose, schedule, etc."
                            rows={5}
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <FormField
                      control={form.control}
                      name="date"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground"
                                  )}
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>Pick a date</span>
                                  )}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                disabled={(date) => date < new Date()}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="time"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Time</FormLabel>
                          <FormControl>
                            <Input type="time" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Status</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select status" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="upcoming">Upcoming</SelectItem>
                              <SelectItem value="active">Active</SelectItem>
                              <SelectItem value="cancelled">Cancelled</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="price"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Price (₹)</FormLabel>
                          <FormControl>
                            <Input type="number" min="0" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="capacity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Capacity</FormLabel>
                          <FormControl>
                            <Input type="number" min="1" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="clubId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Club</FormLabel>
                          <Select
                            onValueChange={(value) => field.onChange(parseInt(value, 10))}
                            value={field.value?.toString() || "1"}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select club" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {clubOptions && clubOptions.length > 0 ? (
                                clubOptions.map((club: any) => (
                                  <SelectItem key={club.id} value={club.id.toString()}>
                                    {club.name}
                                  </SelectItem>
                                ))
                              ) : (
                                <SelectItem value="1">Default Club</SelectItem>
                              )}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="categoryId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select
                            onValueChange={(value) => field.onChange(parseInt(value, 10))}
                            value={field.value?.toString() || "1"}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {categories && categories.length > 0 ? (
                                categories.map((category: any) => (
                                  <SelectItem key={category.id} value={category.id.toString()}>
                                    {category.name}
                                  </SelectItem>
                                ))
                              ) : (
                                <SelectItem value="1">Default Category</SelectItem>
                              )}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="image"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Event Image</FormLabel>
                        <div className="space-y-4">
                          <div className="flex flex-col space-y-2">
                            <FormLabel className="text-sm text-gray-500">Option 1: Enter Image URL</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="https://example.com/event-image.jpg" 
                                {...field} 
                                className="flex-grow"
                              />
                            </FormControl>
                          </div>
                          
                          <div className="flex flex-col space-y-2">
                            <FormLabel className="text-sm text-gray-500">Option 2: Select from Gallery</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select image" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {eventImageOptions.map((url, index) => (
                                  <SelectItem key={index} value={url}>
                                    Event Image {index + 1}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        
                        {field.value && (
                          <div className="mt-4">
                            <h4 className="text-sm font-medium mb-2">Preview:</h4>
                            <img
                              src={field.value}
                              alt="Event preview"
                              className="rounded-md h-40 w-full object-cover"
                              onError={(e) => {
                                e.currentTarget.src = eventImageOptions[0];
                              }}
                            />
                          </div>
                        )}
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={createEventMutation.isPending}
                  >
                    {createEventMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      "Publish Event"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}