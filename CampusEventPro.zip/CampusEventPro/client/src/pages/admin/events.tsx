import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import AdminLayout from "@/components/admin-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  useForm, 
  Controller,
  useFieldArray
} from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertEventSchema, Event, Club, Category } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { Loader2, Plus, Trash2, Calendar, Edit } from "lucide-react";

// Extend the insertEventSchema with validations
const eventFormSchema = insertEventSchema.extend({
  date: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Please enter a valid date",
  }),
  price: z.number().min(0, "Price must be a positive number"),
  capacity: z.number().min(1, "Capacity must be at least 1"),
});

type EventFormValues = z.infer<typeof eventFormSchema>;

export default function AdminEvents() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const [showAddEventDialog, setShowAddEventDialog] = useState(false);
  const [editingEventId, setEditingEventId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Extract event ID from URL if present
  useEffect(() => {
    const params = new URLSearchParams(location.split("?")[1]);
    const id = params.get("id");
    if (id) {
      setEditingEventId(Number(id));
      setShowAddEventDialog(true);
    }
  }, [location]);

  // Fetch events
  const { data: events, isLoading: eventsLoading } = useQuery<(Event & {
    club?: { name: string; icon: string; backgroundColor: string };
    category?: { name: string; color: string };
  })[]>({
    queryKey: ["/api/events"],
  });

  // Fetch clubs
  const { data: clubs } = useQuery<Club[]>({
    queryKey: ["/api/clubs"],
  });

  // Fetch categories
  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  // Get single event for editing
  const { data: editingEvent, isLoading: editingEventLoading } = useQuery<Event>({
    queryKey: [`/api/events/${editingEventId}`],
    enabled: !!editingEventId,
  });

  // Form setup
  const form = useForm<EventFormValues>({
    resolver: zodResolver(eventFormSchema),
    defaultValues: {
      title: "",
      description: "",
      date: "",
      time: "",
      location: "",
      price: 0,
      capacity: 50,
      image: "",
      status: "active",
      clubId: 0,
      categoryId: 0,
      highlights: [],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "highlights",
  });

  // Set form values when editing
  useEffect(() => {
    if (editingEvent) {
      const formattedDate = new Date(editingEvent.date).toISOString().split("T")[0];
      
      form.reset({
        ...editingEvent,
        date: formattedDate,
        highlights: editingEvent.highlights || [],
      });
    }
  }, [editingEvent, form]);

  // Create Event Mutation
  const createEventMutation = useMutation({
    mutationFn: async (data: EventFormValues) => {
      const res = await apiRequest("POST", "/api/events", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Event created",
        description: "The event has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      handleCloseDialog();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create event",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update Event Mutation
  const updateEventMutation = useMutation({
    mutationFn: async (data: EventFormValues & { id: number }) => {
      const { id, ...eventData } = data;
      const res = await apiRequest("PATCH", `/api/events/${id}`, eventData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Event updated",
        description: "The event has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      handleCloseDialog();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update event",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete Event Mutation
  const deleteEventMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/events/${id}`);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to delete event");
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Event deleted",
        description: "The event has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete event",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: EventFormValues) => {
    if (editingEventId) {
      updateEventMutation.mutate({ ...data, id: editingEventId });
    } else {
      createEventMutation.mutate(data);
    }
  };

  const handleAddEvent = () => {
    form.reset({
      title: "",
      description: "",
      date: "",
      time: "",
      location: "",
      price: 0,
      capacity: 50,
      image: "",
      status: "active",
      clubId: 0,
      categoryId: 0,
      highlights: [],
    });
    setEditingEventId(null);
    setShowAddEventDialog(true);
  };

  const handleEditEvent = (id: number) => {
    setEditingEventId(id);
    setShowAddEventDialog(true);
    // Update URL without refreshing the page
    setLocation(`/admin/events?id=${id}`, { replace: true });
  };
  
  const handleDeleteEvent = (id: number, eventTitle: string) => {
    if (window.confirm(`Are you sure you want to delete the event "${eventTitle}"? This action cannot be undone.`)) {
      deleteEventMutation.mutate(id);
    }
  };

  const handleCloseDialog = () => {
    setShowAddEventDialog(false);
    setEditingEventId(null);
    setLocation("/admin/events", { replace: true });
  };

  // Filter events based on search query
  const filteredEvents = events?.filter((event) =>
    event.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AdminLayout title="Manage Events">
      <div className="mb-6 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex-1 max-w-md">
          <Input
            placeholder="Search events..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full"
          />
        </div>
        <Button onClick={handleAddEvent}>
          <Plus className="h-4 w-4 mr-2" />
          Add New Event
        </Button>
      </div>

      <div className="rounded-md border bg-white dark:bg-gray-800 overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Event</TableHead>
                <TableHead>Club</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Capacity</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {eventsLoading ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-10">
                    <Loader2 className="h-8 w-8 animate-spin mx-auto" />
                  </TableCell>
                </TableRow>
              ) : filteredEvents && filteredEvents.length > 0 ? (
                filteredEvents.map((event) => (
                  <TableRow key={event.id}>
                    <TableCell>
                      <div className="font-medium">{event.title}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400 truncate max-w-xs">
                        {event.description.substring(0, 60)}
                        {event.description.length > 60 ? "..." : ""}
                      </div>
                    </TableCell>
                    <TableCell>
                      {event.club?.name || "Unknown"}
                    </TableCell>
                    <TableCell>
                      {format(new Date(event.date), "MMM d, yyyy")}
                    </TableCell>
                    <TableCell>
                      {event.registrationsCount}/{event.capacity}
                    </TableCell>
                    <TableCell>
                      {event.price === 0 ? "Free" : `₹${event.price}`}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={
                          event.status === "active"
                            ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                            : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                        }
                      >
                        {event.status === "active" ? "Active" : "Draft"}
                      </Badge>
                    </TableCell>
                    <TableCell className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditEvent(event.id)}
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                        onClick={() => handleDeleteEvent(event.id, event.title)}
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        Delete
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-10 text-gray-500">
                    No events found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Add/Edit Event Dialog */}
      <Dialog open={showAddEventDialog} onOpenChange={setShowAddEventDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingEventId ? "Edit Event" : "Add New Event"}</DialogTitle>
          </DialogHeader>

          {editingEventId && editingEventLoading ? (
            <div className="flex justify-center py-10">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : (
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Title</label>
                  <Input
                    {...form.register("title")}
                    placeholder="Event title"
                    className="w-full"
                  />
                  {form.formState.errors.title && (
                    <p className="text-sm text-red-500">
                      {form.formState.errors.title.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Image URL</label>
                  <Input
                    {...form.register("image")}
                    placeholder="Image URL"
                    className="w-full"
                  />
                  {form.formState.errors.image && (
                    <p className="text-sm text-red-500">
                      {form.formState.errors.image.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Club</label>
                  <Controller
                    control={form.control}
                    name="clubId"
                    render={({ field }) => (
                      <Select
                        value={field.value.toString()}
                        onValueChange={(value) => field.onChange(parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select a club" />
                        </SelectTrigger>
                        <SelectContent>
                          {clubs?.map((club) => (
                            <SelectItem key={club.id} value={club.id.toString()}>
                              {club.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  />
                  {form.formState.errors.clubId && (
                    <p className="text-sm text-red-500">
                      {form.formState.errors.clubId.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Category</label>
                  <Controller
                    control={form.control}
                    name="categoryId"
                    render={({ field }) => (
                      <Select
                        value={field.value.toString()}
                        onValueChange={(value) => field.onChange(parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories?.map((category) => (
                            <SelectItem key={category.id} value={category.id.toString()}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  />
                  {form.formState.errors.categoryId && (
                    <p className="text-sm text-red-500">
                      {form.formState.errors.categoryId.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Date</label>
                  <Input
                    {...form.register("date")}
                    type="date"
                    className="w-full"
                  />
                  {form.formState.errors.date && (
                    <p className="text-sm text-red-500">
                      {form.formState.errors.date.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Time</label>
                  <Input
                    {...form.register("time")}
                    placeholder="e.g., 10:00 AM - 5:00 PM"
                    className="w-full"
                  />
                  {form.formState.errors.time && (
                    <p className="text-sm text-red-500">
                      {form.formState.errors.time.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Location</label>
                  <Input
                    {...form.register("location")}
                    placeholder="Event location"
                    className="w-full"
                  />
                  {form.formState.errors.location && (
                    <p className="text-sm text-red-500">
                      {form.formState.errors.location.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Status</label>
                  <Controller
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="draft">Draft</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  />
                  {form.formState.errors.status && (
                    <p className="text-sm text-red-500">
                      {form.formState.errors.status.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Price (₹)</label>
                  <Input
                    {...form.register("price", { valueAsNumber: true })}
                    type="number"
                    min="0"
                    step="1"
                    className="w-full"
                  />
                  {form.formState.errors.price && (
                    <p className="text-sm text-red-500">
                      {form.formState.errors.price.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Capacity</label>
                  <Input
                    {...form.register("capacity", { valueAsNumber: true })}
                    type="number"
                    min="1"
                    className="w-full"
                  />
                  {form.formState.errors.capacity && (
                    <p className="text-sm text-red-500">
                      {form.formState.errors.capacity.message}
                    </p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Description</label>
                <Textarea
                  {...form.register("description")}
                  placeholder="Event description"
                  className="w-full min-h-[100px]"
                />
                {form.formState.errors.description && (
                  <p className="text-sm text-red-500">
                    {form.formState.errors.description.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-medium">Highlights</label>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => append("")}
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    Add Highlight
                  </Button>
                </div>
                
                <div className="space-y-2">
                  {fields.map((field, index) => (
                    <div key={field.id} className="flex items-center space-x-2">
                      <Input
                        {...form.register(`highlights.${index}`)}
                        placeholder={`Highlight ${index + 1}`}
                        className="flex-grow"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => remove(index)}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={handleCloseDialog}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createEventMutation.isPending || updateEventMutation.isPending}
                >
                  {createEventMutation.isPending || updateEventMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      {editingEventId ? "Updating..." : "Creating..."}
                    </>
                  ) : (
                    <>{editingEventId ? "Update Event" : "Create Event"}</>
                  )}
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
