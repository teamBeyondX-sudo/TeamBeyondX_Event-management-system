import { useEffect, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Trash, AlertCircle } from "lucide-react";
import { Club } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import AdminLayout from "@/components/admin-layout";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "@/hooks/use-toast";

export default function AdminClubs() {
  const [clubToDelete, setClubToDelete] = useState<Club | null>(null);
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);

  // Query to fetch all clubs
  const { data: clubs, isLoading: clubsLoading } = useQuery<Club[]>({
    queryKey: ["/api/clubs"],
    refetchOnWindowFocus: false,
  });

  // Mutation to delete a club
  const deleteMutation = useMutation({
    mutationFn: async (clubId: number) => {
      const response = await apiRequest("DELETE", `/api/clubs/${clubId}`);
      return response.json();
    },
    onSuccess: () => {
      // Invalidate and refetch clubs query to update the UI
      queryClient.invalidateQueries({ queryKey: ["/api/clubs"] });
      toast({
        title: "Club deleted",
        description: "The club has been successfully deleted.",
      });
      setShowDeleteAlert(false);
      setClubToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete club. Please try again.",
        variant: "destructive",
      });
      setShowDeleteAlert(false);
    },
  });

  // Function to handle the deletion of a club
  const handleDeleteClick = (club: Club) => {
    setClubToDelete(club);
    setShowDeleteAlert(true);
  };

  // Function to confirm and process club deletion
  const confirmDelete = () => {
    if (clubToDelete) {
      deleteMutation.mutate(clubToDelete.id);
    }
  };

  return (
    <AdminLayout title="Manage Clubs">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Club Management</h2>
        <p className="text-gray-600 dark:text-gray-400">
          Manage all clubs in the system. You can delete clubs that don't have registered events.
        </p>
      </div>

      {clubsLoading ? (
        <div className="flex justify-center my-8">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      ) : (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[50px]">ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Description</TableHead>
                <TableHead className="text-center">Members</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {clubs && clubs.length > 0 ? (
                clubs.map((club) => (
                  <TableRow key={club.id}>
                    <TableCell className="font-medium">{club.id}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <div
                          className="w-8 h-8 rounded-full mr-2 flex items-center justify-center text-white"
                          style={{ backgroundColor: club.backgroundColor }}
                        >
                          <i className={club.icon}></i>
                        </div>
                        {club.name}
                      </div>
                    </TableCell>
                    <TableCell className="max-w-md truncate">{club.description}</TableCell>
                    <TableCell className="text-center">{club.memberCount}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        onClick={() => handleDeleteClick(club)}
                        variant="outline"
                        size="sm"
                        className="text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950"
                      >
                        <Trash className="h-4 w-4 mr-1" />
                        Delete
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-6">
                    <div className="flex flex-col items-center justify-center text-gray-500 dark:text-gray-400">
                      <AlertCircle className="h-10 w-10 mb-2" />
                      <p>No clubs found</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Confirmation Dialog for Deleting a Club */}
      <AlertDialog open={showDeleteAlert} onOpenChange={setShowDeleteAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the club "{clubToDelete?.name}". 
              All club memberships will be removed. This action cannot be undone.
              <br /><br />
              Note: Clubs with events that have registrations cannot be deleted.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-500 hover:bg-red-600 text-white"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}