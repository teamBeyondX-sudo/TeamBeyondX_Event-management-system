import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import AdminLayout from "@/components/admin-layout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";
import { Loader2, Search } from "lucide-react";
import { Event } from "@shared/schema";

type Registration = {
  id: number;
  userId: number;
  eventId: number;
  teamName: string | null;
  teamSize: number;
  requirements: string | null;
  paymentStatus: string;
  registrationDate: string;
  paymentAmount: number;
  transactionId: string | null;
  user: {
    id: number;
    fullName: string;
    email: string;
    phone: string | null;
  };
};

export default function AdminParticipants() {
  const [selectedEventId, setSelectedEventId] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const [registrations, setRegistrations] = useState<Registration[]>([]);

  // Fetch events for dropdown
  const { data: events, isLoading: eventsLoading } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });

  // Fetch registrations for selected event
  const { data: eventRegistrations, isLoading: registrationsLoading } = useQuery<Registration[]>({
    queryKey: [`/api/events/${selectedEventId}/registrations`],
    enabled: !!selectedEventId,
  });

  // Update registrations when data is fetched
  useEffect(() => {
    if (eventRegistrations) {
      setRegistrations(eventRegistrations);
    }
  }, [eventRegistrations]);

  // Filter registrations based on search query
  const filteredRegistrations = registrations.filter((reg) => {
    const fullName = reg.user.fullName.toLowerCase();
    const email = reg.user.email.toLowerCase();
    const teamName = reg.teamName ? reg.teamName.toLowerCase() : "";
    const searchTerm = searchQuery.toLowerCase();

    return (
      fullName.includes(searchTerm) ||
      email.includes(searchTerm) ||
      teamName.includes(searchTerm)
    );
  });

  // Handle event selection change
  const handleEventChange = (eventId: string) => {
    setSelectedEventId(eventId);
  };

  // Format date
  const formatDate = (dateString: string) => {
    return format(new Date(dateString), "MMM d, yyyy 'at' h:mm a");
  };

  return (
    <AdminLayout title="Participants">
      <div className="mb-6 flex flex-col md:flex-row gap-4 items-start md:items-center">
        <div className="w-full md:w-1/3">
          <Select value={selectedEventId} onValueChange={handleEventChange}>
            <SelectTrigger>
              <SelectValue placeholder="Select an event to view participants" />
            </SelectTrigger>
            <SelectContent>
              {eventsLoading ? (
                <div className="flex justify-center p-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                </div>
              ) : (
                events?.map((event) => (
                  <SelectItem key={event.id} value={event.id.toString()}>
                    {event.title}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
        </div>

        <div className="relative w-full md:w-1/3">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search participants..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {!selectedEventId ? (
        <div className="bg-white dark:bg-gray-800 rounded-lg p-8 text-center">
          <h3 className="text-lg font-medium mb-2">No Event Selected</h3>
          <p className="text-gray-500 dark:text-gray-400">
            Please select an event from the dropdown to view its participants.
          </p>
        </div>
      ) : registrationsLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="rounded-md border bg-white dark:bg-gray-800 overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Participant</TableHead>
                  <TableHead>Team</TableHead>
                  <TableHead>Registration Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Payment Status</TableHead>
                  <TableHead>Requirements</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRegistrations.length > 0 ? (
                  filteredRegistrations.map((registration) => (
                    <TableRow key={registration.id}>
                      <TableCell>
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-300">
                            <span className="font-medium">
                              {registration.user.fullName.substring(0, 2).toUpperCase()}
                            </span>
                          </div>
                          <div className="ml-3">
                            <div className="font-medium">{registration.user.fullName}</div>
                            <div className="text-sm text-gray-500 dark:text-gray-400">
                              {registration.user.email}
                            </div>
                            {registration.user.phone && (
                              <div className="text-xs text-gray-500 dark:text-gray-400">
                                {registration.user.phone}
                              </div>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {registration.teamName ? (
                          <div>
                            <div className="font-medium">{registration.teamName}</div>
                            <div className="text-sm text-gray-500 dark:text-gray-400">
                              {registration.teamSize} members
                            </div>
                          </div>
                        ) : (
                          <span className="text-gray-500 dark:text-gray-400">
                            Individual registration
                          </span>
                        )}
                      </TableCell>
                      <TableCell>
                        {formatDate(registration.registrationDate)}
                      </TableCell>
                      <TableCell>₹{registration.paymentAmount}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            registration.paymentStatus === "completed"
                              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                              : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                          }
                        >
                          {registration.paymentStatus === "completed" ? "Paid" : "Pending"}
                        </Badge>
                        {registration.transactionId && (
                          <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            ID: {registration.transactionId}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        {registration.requirements ? (
                          <div className="max-w-xs truncate">
                            {registration.requirements}
                          </div>
                        ) : (
                          <span className="text-gray-500 dark:text-gray-400">None</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-10 text-gray-500">
                      {searchQuery
                        ? "No participants match your search criteria"
                        : "No registrations found for this event"}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
