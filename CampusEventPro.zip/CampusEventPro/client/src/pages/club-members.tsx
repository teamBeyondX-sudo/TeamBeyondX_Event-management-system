import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { format } from "date-fns";
import Layout from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, ChevronLeft, Mail, User, Calendar } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

type ClubMember = {
  user: {
    id: number;
    username: string;
    fullName: string;
    email: string;
  };
  role: string;
  joinDate: string;
};

type ClubMembersResponse = {
  clubName: string;
  clubIcon: string;
  clubBackgroundColor: string;
  totalMembers: number;
  members: ClubMember[];
};

export default function ClubMembers() {
  // Get the club ID from the URL
  const [match, params] = useRoute<{ id: string }>("/clubs/:id/members");
  const clubId = params?.id ? parseInt(params.id, 10) : 0;

  // Fetch club members
  const { data, isLoading, error } = useQuery<ClubMembersResponse>({
    queryKey: [`/api/clubs/${clubId}/members`],
    enabled: !!clubId,
  });

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center items-center py-20">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (error || !data) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <Button asChild variant="outline" className="mb-6">
            <Link href={`/clubs/${clubId}`}>
              <a className="flex items-center">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Club
              </a>
            </Link>
          </Button>
          
          <div className="text-center py-16 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <h3 className="text-xl font-medium mb-4">Error Loading Club Members</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-8">
              There was a problem loading the club members.
            </p>
            <Button variant="outline" onClick={() => window.location.reload()}>
              Try Again
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12">
        <Button asChild variant="outline" className="mb-6">
          <Link href={`/clubs/${clubId}`}>
            <a className="flex items-center">
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Club
            </a>
          </Link>
        </Button>

        <Card>
          <CardHeader className="pb-4" style={{ backgroundColor: data.clubBackgroundColor, color: 'white' }}>
            <div className="flex items-center">
              <div className="h-12 w-12 rounded-full bg-white/20 flex items-center justify-center">
                <i className={`${data.clubIcon} text-xl`}></i>
              </div>
              <div className="ml-4">
                <CardTitle className="text-2xl font-poppins">{data.clubName}</CardTitle>
                <p className="text-white/80 mt-1">
                  {data.totalMembers} {data.totalMembers === 1 ? 'Member' : 'Members'}
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Member</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Join Date</TableHead>
                    <TableHead>Email</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.members.map((member) => (
                    <TableRow key={member.user.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                            <User className="h-4 w-4" />
                          </div>
                          <div className="ml-3">
                            <div>{member.user.fullName}</div>
                            <div className="text-xs text-gray-500 dark:text-gray-400">
                              @{member.user.username}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={member.role === "leader" ? "default" : "outline"}>
                          {member.role}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                          {format(new Date(member.joinDate), "MMM d, yyyy")}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Mail className="h-4 w-4 mr-2 text-gray-400" />
                          {member.user.email}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            {data.members.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500 dark:text-gray-400">
                  No members found for this club.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}