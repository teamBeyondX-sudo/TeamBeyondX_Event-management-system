import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import Layout from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Search, Users } from "lucide-react";
import { Club } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function ClubsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch all clubs
  const { data: clubs, isLoading } = useQuery<Club[]>({
    queryKey: ["/api/clubs"],
  });

  // Join club mutation
  const joinClubMutation = useMutation({
    mutationFn: async (clubId: number) => {
      const res = await apiRequest("POST", `/api/clubs/${clubId}/join`, { role: "member" });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Club joined successfully!",
        description: "You are now a member of this club.",
      });
      // Invalidate both clubs and my-clubs queries
      queryClient.invalidateQueries({ queryKey: ["/api/clubs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/my-clubs"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to join club",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Filter clubs based on search term
  const filteredClubs = clubs
    ? clubs.filter(
        (club) =>
          club.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          club.description.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  const handleJoinClub = (clubId: number) => {
    joinClubMutation.mutate(clubId);
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center items-center py-20">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <h1 className="font-poppins font-bold text-3xl">Explore Clubs</h1>
          
          <div className="flex w-full md:w-auto gap-4">
            <div className="relative w-full md:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
              <Input
                type="text"
                placeholder="Search clubs..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <Link href="/my-clubs">
              <Button variant="outline">My Clubs</Button>
            </Link>
          </div>
        </div>

        {filteredClubs.length === 0 ? (
          <div className="text-center py-16 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <h3 className="text-xl font-medium mb-4">No clubs found</h3>
            <p className="text-gray-500 dark:text-gray-400">
              {searchTerm
                ? `No clubs match "${searchTerm}"`
                : "There are no clubs available"}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredClubs.map((club) => (
              <Card key={club.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div
                  className="p-6 text-white"
                  style={{ backgroundColor: club.backgroundColor }}
                >
                  <div className="flex items-center mb-4">
                    <div className="h-12 w-12 rounded-full bg-white/20 flex items-center justify-center">
                      <i className={`${club.icon} text-xl`}></i>
                    </div>
                    <h3 className="ml-3 font-poppins font-semibold text-xl">{club.name}</h3>
                  </div>
                  <div className="flex items-center text-white/80 text-sm">
                    <Users className="h-4 w-4 mr-2" />
                    <span>{club.memberCount} members</span>
                  </div>
                </div>
                <CardContent className="p-6">
                  <p className="text-gray-600 dark:text-gray-300 mb-6 line-clamp-3">
                    {club.description}
                  </p>
                  
                  <div className="flex space-x-3">
                    <Button
                      onClick={() => handleJoinClub(club.id)}
                      disabled={joinClubMutation.isPending}
                      className="flex-1"
                    >
                      {joinClubMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : null}
                      Join Club
                    </Button>
                    <Link href={`/clubs/${club.id}`}>
                      <Button variant="outline" className="flex-1">
                        View Details
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}