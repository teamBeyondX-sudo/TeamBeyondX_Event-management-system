import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import Layout from "@/components/layout";
import EventCard from "@/components/event-card";
import EventFilter from "@/components/event-filter";
import { Loader2 } from "lucide-react";
import { Event } from "@shared/schema";

export default function EventsPage() {
  const [filters, setFilters] = useState<{
    search?: string;
    categoryId?: number;
    clubId?: number;
  }>({});

  // Construct query string from filters
  let queryString = "";
  if (filters.search) queryString += `search=${encodeURIComponent(filters.search)}&`;
  if (filters.categoryId) queryString += `categoryId=${filters.categoryId}&`;
  if (filters.clubId) queryString += `clubId=${filters.clubId}&`;
  queryString = queryString ? `?${queryString.slice(0, -1)}` : "";

  // Fetch events with filters
  const { data: events, isLoading } = useQuery<(Event & {
    club?: { name: string; icon: string; backgroundColor: string };
    category?: { name: string; color: string };
  })[]>({
    queryKey: [`/api/events${queryString}`],
  });

  const handleFilterChange = (newFilters: {
    search?: string;
    categoryId?: number;
    clubId?: number;
  }) => {
    setFilters(newFilters);
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12">
        <EventFilter onFilterChange={handleFilterChange} />

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : events && events.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {events.map((event) => (
              <Link key={event.id} href={`/events/${event.id}`}>
                <a className="block">
                  <EventCard event={event} />
                </a>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg mt-8">
            <h3 className="text-lg font-medium mb-2">No events found</h3>
            <p className="text-gray-500 dark:text-gray-400">
              {filters.search
                ? `No events match the search term "${filters.search}"`
                : "There are no events matching your filters."}
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
}
