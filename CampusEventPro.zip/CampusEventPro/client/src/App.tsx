import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import EventsPage from "@/pages/events-page";
import EventDetails from "@/pages/event-details";
import ClubsPage from "@/pages/clubs-page";
import ClubDetails from "@/pages/club-details";
import MyClubs from "@/pages/my-clubs";
import ClubMembers from "@/pages/club-members";
import MyRegistrations from "@/pages/my-registrations";
import CreateClub from "@/pages/create-club";
import CreateEvent from "@/pages/create-event";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminEvents from "@/pages/admin/events";
import AdminParticipants from "@/pages/admin/participants";
import AdminClubs from "@/pages/admin/clubs";

import { ThemeProvider } from "@/components/ui/theme-provider";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute, AdminRoute } from "./lib/protected-route";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <Route path="/" component={HomePage} />
      <Route path="/events" component={EventsPage} />
      <Route path="/events/:id" component={EventDetails} />
      <Route path="/clubs" component={ClubsPage} />
      <Route path="/clubs/:id" component={ClubDetails} />
      <ProtectedRoute path="/my-clubs" component={MyClubs} />
      <ProtectedRoute path="/create-club" component={CreateClub} />
      <AdminRoute path="/create-event" component={CreateEvent} />
      <ProtectedRoute path="/clubs/:id/members" component={ClubMembers} />
      <ProtectedRoute path="/my-registrations" component={MyRegistrations} />
      <AdminRoute path="/admin" component={AdminDashboard} />
      <AdminRoute path="/admin/events" component={AdminEvents} />
      <AdminRoute path="/admin/clubs" component={AdminClubs} />
      <AdminRoute path="/admin/participants" component={AdminParticipants} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="dark">
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
