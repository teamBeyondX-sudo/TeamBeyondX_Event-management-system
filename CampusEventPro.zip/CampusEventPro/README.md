# Brainware University - Campus Events & Clubs Management System

A comprehensive web application for managing university campus events, clubs, and student engagement activities. This platform serves as a centralized hub for the Brainware University community to discover, register, and participate in campus events and clubs.

## 🎓 Overview

The Brainware University Campus Events & Clubs Management System is designed to streamline event discovery, club management, and event registration for the university community. With a modern, responsive interface featuring a continuous 3D background, the system provides an immersive and engaging user experience.

## ✨ Features

### 🔐 Authentication System
- Role-based authentication (Student/Admin)
- Secure login and registration
- Protected routes and permission management

### 📅 Event Management
- Browse upcoming and past events
- Filter events by category, club, or search query
- View detailed event information including date, time, location, capacity, and price
- Event registration with optional team details
- Payment processing integration (via PhonePe)
- Event status indicators (Upcoming/Closed)

### 🏛️ Club Management
- Browse available university clubs
- View club details and members
- Join clubs as a member
- Create new clubs (authenticated users)
- Manage club membership

### 👤 User Features
- View personal registrations and payment status
- Track club memberships
- Register for events and manage registration details

### 🛠️ Admin Features
- Comprehensive dashboard for administrators
- Create, edit, and delete events and clubs
- Manage event categories
- View and manage registrations
- Ensure data integrity (prevent deletion of events with registrations)

## 🖥️ Technical Stack

### Frontend
- **React**: UI library for building component-based interfaces
- **TypeScript**: Static typing for improved code quality
- **TailwindCSS**: Utility-first CSS framework for styling
- **Shadcn UI**: Component library for consistent design
- **Wouter**: Lightweight router for navigation
- **React Query**: Data fetching and state management
- **Zod**: Schema validation
- **Spline**: 3D background elements

### Backend
- **Node.js**: JavaScript runtime
- **Express**: Web framework for APIs
- **PostgreSQL**: Database for persistent storage
- **Drizzle ORM**: Type-safe database operations
- **Passport.js**: Authentication middleware

### Styling
- Custom design system with glass-morphism effects
- Responsive design for all device sizes
- 3D continuous background with Spline
- Dark mode by default with elegant purple accent color

## 🚀 Getting Started

### Prerequisites
- Node.js (v18+)
- PostgreSQL database

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd brainware-university-events
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
Create a `.env` file in the root directory with the following contents:
```
DATABASE_URL=postgresql://username:password@localhost:5432/brainware_events
SESSION_SECRET=your_secure_secret_key
```

4. Initialize the database:
```bash
npm run db:push
```

5. Start the development server:
```bash
npm run dev
```

6. Open your browser and navigate to `http://localhost:5000`

## 🔧 Database Schema

The system uses the following core entities:

- **Users**: Student and admin accounts
- **Clubs**: Campus clubs and organizations
- **ClubMemberships**: Relationships between users and clubs
- **Categories**: Event categories (Tech, Cultural, Sports, etc.)
- **Events**: Campus events with details and registration info
- **Registrations**: User registrations for events, including payment status

## 👥 User Roles

### Students
- Browse and register for events
- Join and create clubs
- Manage personal registrations and club memberships

### Administrators
- All student capabilities
- Create, edit, and delete events and clubs
- Access the admin dashboard
- Manage system data and content

## 📱 UI Features

- **Glass-morphism**: Elegant transparent UI elements with subtle backdrop blur
- **3D Background**: Continuous Spline 3D background across all pages
- **Responsive Design**: Optimized for mobile, tablet, and desktop
- **Animations**: Smooth transitions and interactions throughout the site
- **Dark Theme**: Sleek dark interface with purple accent color

## 📷 Screenshots

[Screenshots would be included here in the final README]

## 🧰 Development

### Project Structure
- `/client`: Frontend React application
- `/server`: Backend Express API
- `/shared`: Shared TypeScript types and schemas
- `/database`: Database configuration and migrations

### Available Scripts
- `npm run dev`: Start the development server
- `npm run db:push`: Push schema changes to the database
- `npm run build`: Build the application for production
- `npm run start`: Start the production server

## 🔒 Authentication

This system uses Passport.js with a session-based authentication strategy. User passwords are securely hashed before storage.

Default admin credentials:
- Username: `akinchan_25`
- Password: `123456`

## 📚 API Documentation

The backend provides a RESTful API with the following core endpoints:

- `/api/auth`: Authentication endpoints
- `/api/clubs`: Club management
- `/api/events`: Event management and queries
- `/api/registrations`: Event registration management
- `/api/categories`: Event category management

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 📬 Contact

For any inquiries, please contact Brainware University at [contact@brainwareuniversity.ac.in](mailto:contact@brainwareuniversity.ac.in).

---

&copy; 2025 Brainware University. All rights reserved.